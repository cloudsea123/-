# 政企智能舆情分析报告生成系统

基于 Node.js + Express + Layui 的 B/S 架构 Web 应用系统。

## 功能特性

### 用户认证
- 用户名/密码登录（密码加密存储）
- Session 会话管理
- 退出登录

### 后台管理
- **用户管理**：用户的增删改查、状态管理
- **角色管理**：管理员/普通用户角色配置
  - 管理员：拥有所有功能权限
  - 普通用户：仅可查看数据报表和最新报告
- **系统设置**：应用名称、Logo 自定义

### 数据展示
- 控制台仪表盘
- 舆情趋势分析图表
- 舆情类型/来源分布
- 报告列表与详情

## 技术栈

- **后端**：Node.js + Express
- **前端**：Layui 2.9.8
- **数据库**：SQLite (better-sqlite3)
- **图表**：ECharts 5.4
- **密码加密**：bcryptjs

## 快速开始

### 1. 安装依赖

```bash
npm install
```

### 2. 启动服务

```bash
npm start
```

或开发模式（自动重启）：

```bash
npm run dev
```

### 3. 访问系统

打开浏览器访问：http://localhost:3000

### 默认账户

- **管理员**：admin / admin123

## 目录结构

```
├── server.js           # 服务端入口
├── package.json        # 项目配置
├── data/               # 数据库文件
├── uploads/            # 上传文件
└── public/             # 静态资源
    ├── login.html      # 登录页
    ├── index.html      # 主框架页
    ├── assets/
    │   ├── css/        # 样式文件
    │   ├── js/         # 脚本文件
    │   └── images/     # 图片资源
    └── views/          # 页面视图
        ├── dashboard.html  # 控制台
        ├── reports.html    # 报告管理
        ├── users.html      # 用户管理
        ├── roles.html      # 角色管理
        └── settings.html   # 系统设置
```

## 响应式设计

系统采用响应式布局，支持：
- 桌面端（>768px）
- 平板端（768px）
- 移动端（<480px）

## API 接口

### 认证接口
- `POST /api/login` - 用户登录
- `POST /api/logout` - 退出登录
- `GET /api/user/info` - 获取当前用户信息

### 用户管理
- `GET /api/users` - 获取用户列表
- `POST /api/users` - 添加用户
- `PUT /api/users/:id` - 更新用户
- `DELETE /api/users/:id` - 删除用户

### 角色管理
- `GET /api/roles` - 获取角色列表
- `POST /api/roles` - 添加角色
- `PUT /api/roles/:id` - 更新角色
- `DELETE /api/roles/:id` - 删除角色

### 系统设置
- `GET /api/settings` - 获取系统设置
- `PUT /api/settings` - 更新系统设置
- `POST /api/upload/logo` - 上传Logo

### 报告管理
- `GET /api/reports` - 获取报告列表
- `GET /api/reports/latest` - 获取最新报告
- `GET /api/reports/:id` - 获取报告详情
- `POST /api/reports` - 添加报告
- `PUT /api/reports/:id` - 更新报告
- `DELETE /api/reports/:id` - 删除报告

### 仪表盘
- `GET /api/dashboard/stats` - 获取统计数据

## 许可证

MIT License
