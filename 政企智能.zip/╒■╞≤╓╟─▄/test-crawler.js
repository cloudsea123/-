/**
 * 爬虫模块测试脚本
 */

const { search, searchMultiplePages } = require('./crawler');

async function main() {
  console.log('=== 测试聚合搜索 ===\n');
  
  try {
    const result = await search('科技');
    console.log('关键字:', result.keyword);
    console.log('获取数量:', result.total);
    console.log('\n前5条结果:');
    
    result.items.slice(0, 5).forEach((item, i) => {
      console.log(`\n[${i+1}] ${item.title}`);
      console.log(`    来源: ${item.source}`);
      console.log(`    链接: ${item.url?.substring(0, 60)}...`);
    });
  } catch (e) {
    console.error('Error:', e.message);
  }
}

main();
