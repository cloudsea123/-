/**
 * 爬虫模块测试脚本
 * 运行: node test-crawler.js
 */

const { search, batchSearch, searchMultiplePages } = require('./crawler');

async function testCrawler() {
  console.log('========== 百度新闻爬虫测试 ==========\n');

  try {
    // 测试1: 单关键字搜索
    console.log('【测试1】单关键字搜索: 人工智能');
    console.log('-'.repeat(50));
    
    const result1 = await search('人工智能');
    console.log(`搜索关键字: ${result1.keyword}`);
    console.log(`获取数量: ${result1.total}`);
    console.log(`抓取时间: ${result1.crawlTime}`);
    console.log('\n前3条结果:');
    
    result1.items.slice(0, 3).forEach((item, index) => {
      console.log(`\n[${index + 1}]`);
      console.log(`  标题: ${item.title}`);
      console.log(`  概要: ${item.summary.substring(0, 100)}...`);
      console.log(`  封面: ${item.cover || '无'}`);
      console.log(`  原始URL: ${item.url}`);
      console.log(`  来源: ${item.source}`);
    });

    console.log('\n' + '='.repeat(50) + '\n');

    // 测试2: 多页搜索
    console.log('【测试2】多页搜索: 科技创新 (2页)');
    console.log('-'.repeat(50));
    
    const result2 = await searchMultiplePages('科技创新', 2);
    console.log(`搜索关键字: ${result2.keyword}`);
    console.log(`总获取数量: ${result2.total}`);
    console.log('\n前3条结果:');
    
    result2.items.slice(0, 3).forEach((item, index) => {
      console.log(`\n[${index + 1}]`);
      console.log(`  标题: ${item.title}`);
      console.log(`  来源: ${item.source}`);
    });

    console.log('\n' + '='.repeat(50));
    console.log('\n测试完成！爬虫模块工作正常。');

  } catch (error) {
    console.error('测试失败:', error.message);
    console.error(error.stack);
  }
}

testCrawler();
