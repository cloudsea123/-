const express = require('express');
const session = require('express-session');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');
const multer = require('multer');
const { v4: uuidv4 } = require('uuid');
const initSqlJs = require('sql.js');
const axios = require('axios');
const cheerio = require('cheerio');
const iconv = require('iconv-lite');
const { BaiduNewsCrawler, search, batchSearch, searchMultiplePages } = require('./crawler');

const app = express();
const PORT = process.env.PORT || 3000;

let db = null;
const DB_PATH = path.join(__dirname, 'data', 'app.db');

// 确保data目录存在
if (!fs.existsSync(path.join(__dirname, 'data'))) {
  fs.mkdirSync(path.join(__dirname, 'data'), { recursive: true });
}
if (!fs.existsSync(path.join(__dirname, 'uploads'))) {
  fs.mkdirSync(path.join(__dirname, 'uploads'), { recursive: true });
}

// 数据库辅助函数
function saveDatabase() {
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

function runQuery(sql, params = []) {
  try {
    db.run(sql, params);
    saveDatabase();
    return { changes: db.getRowsModified() };
  } catch (e) {
    console.error('SQL Error:', e.message);
    throw e;
  }
}

function getOne(sql, params = []) {
  try {
    const stmt = db.prepare(sql);
    stmt.bind(params);
    if (stmt.step()) {
      const row = stmt.getAsObject();
      stmt.free();
      return row;
    }
    stmt.free();
    return null;
  } catch (e) {
    console.error('SQL Error:', e.message);
    return null;
  }
}

function getAll(sql, params = []) {
  try {
    const stmt = db.prepare(sql);
    stmt.bind(params);
    const results = [];
    while (stmt.step()) {
      results.push(stmt.getAsObject());
    }
    stmt.free();
    return results;
  } catch (e) {
    console.error('SQL Error:', e.message);
    return [];
  }
}

// 初始化数据库
async function initDatabase() {
  const SQL = await initSqlJs();
  
  // 尝试加载现有数据库
  if (fs.existsSync(DB_PATH)) {
    const fileBuffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
  }

  // 创建数据表
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      username TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'user',
      status INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS roles (
      id TEXT PRIMARY KEY,
      name TEXT UNIQUE NOT NULL,
      description TEXT,
      permissions TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS settings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      key TEXT UNIQUE NOT NULL,
      value TEXT,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS reports (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      content TEXT,
      summary TEXT,
      status TEXT DEFAULT 'draft',
      created_by TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // ==================== 资源管理表结构 ====================
  
  // 资源分类表
  db.run(`
    CREATE TABLE IF NOT EXISTS resource_categories (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      code TEXT UNIQUE NOT NULL,
      parent_id TEXT,
      icon TEXT,
      sort_order INTEGER DEFAULT 0,
      description TEXT,
      status INTEGER DEFAULT 1,
      created_by TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // 资源主表 - 存储所有类型资源的通用信息
  db.run(`
    CREATE TABLE IF NOT EXISTS resources (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      category_id TEXT,
      type TEXT NOT NULL DEFAULT 'article',
      source TEXT,
      source_url TEXT,
      cover TEXT,
      summary TEXT,
      content TEXT,
      tags TEXT,
      sentiment TEXT DEFAULT 'neutral',
      importance INTEGER DEFAULT 0,
      view_count INTEGER DEFAULT 0,
      status TEXT DEFAULT 'pending',
      publish_time TEXT,
      created_by TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (category_id) REFERENCES resource_categories(id)
    )
  `);

  // 资源附件表 - 存储资源相关的文件附件
  db.run(`
    CREATE TABLE IF NOT EXISTS resource_attachments (
      id TEXT PRIMARY KEY,
      resource_id TEXT NOT NULL,
      file_name TEXT NOT NULL,
      file_path TEXT NOT NULL,
      file_type TEXT,
      file_size INTEGER,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (resource_id) REFERENCES resources(id) ON DELETE CASCADE
    )
  `);

  // 资源标签表
  db.run(`
    CREATE TABLE IF NOT EXISTS resource_tags (
      id TEXT PRIMARY KEY,
      name TEXT UNIQUE NOT NULL,
      color TEXT DEFAULT '#1890ff',
      use_count INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // 资源-标签关联表
  db.run(`
    CREATE TABLE IF NOT EXISTS resource_tag_relations (
      id TEXT PRIMARY KEY,
      resource_id TEXT NOT NULL,
      tag_id TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (resource_id) REFERENCES resources(id) ON DELETE CASCADE,
      FOREIGN KEY (tag_id) REFERENCES resource_tags(id) ON DELETE CASCADE,
      UNIQUE(resource_id, tag_id)
    )
  `);

  // 采集数据表 - 存储爬虫采集的原始数据
  db.run(`
    CREATE TABLE IF NOT EXISTS collected_data (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      summary TEXT,
      content TEXT,
      cover TEXT,
      url TEXT UNIQUE,
      source TEXT,
      publish_time TEXT,
      deep_crawled INTEGER DEFAULT 0,
      deep_content TEXT,
      keyword TEXT,
      sentiment TEXT DEFAULT 'neutral',
      status TEXT DEFAULT 'pending',
      is_imported INTEGER DEFAULT 0,
      resource_id TEXT,
      created_by TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // 资源操作日志表
  db.run(`
    CREATE TABLE IF NOT EXISTS resource_logs (
      id TEXT PRIMARY KEY,
      resource_id TEXT,
      action TEXT NOT NULL,
      details TEXT,
      operator_id TEXT,
      operator_name TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // 创建索引以提高查询性能
  db.run(`CREATE INDEX IF NOT EXISTS idx_resources_category ON resources(category_id)`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_resources_type ON resources(type)`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_resources_status ON resources(status)`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_resources_sentiment ON resources(sentiment)`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_resources_created_at ON resources(created_at)`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_collected_data_status ON collected_data(status)`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_collected_data_keyword ON collected_data(keyword)`);

  // 初始化默认数据
  const admin = getOne('SELECT * FROM users WHERE role = ?', ['admin']);
  if (!admin) {
    const hashedPassword = bcrypt.hashSync('admin123', 10);
    const now = new Date().toISOString();
    runQuery('INSERT INTO users (id, username, password, role, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)',
      [uuidv4(), 'admin', hashedPassword, 'admin', now, now]);
    console.log('默认管理员账户已创建: admin / admin123');
  }

  // 初始化角色
  const rolesCount = getOne('SELECT COUNT(*) as count FROM roles');
  if (!rolesCount || rolesCount.count === 0) {
    const now = new Date().toISOString();
    runQuery('INSERT INTO roles (id, name, description, permissions, created_at) VALUES (?, ?, ?, ?, ?)',
      [uuidv4(), 'admin', '管理员', JSON.stringify(['all']), now]);
    runQuery('INSERT INTO roles (id, name, description, permissions, created_at) VALUES (?, ?, ?, ?, ?)',
      [uuidv4(), 'user', '普通用户', JSON.stringify(['view_reports', 'view_dashboard']), now]);
  }

  // 初始化系统设置
  const settingsCount = getOne('SELECT COUNT(*) as count FROM settings');
  if (!settingsCount || settingsCount.count === 0) {
    runQuery('INSERT INTO settings (key, value) VALUES (?, ?)', ['app_name', '政企智能舆情分析报告生成系统']);
    runQuery('INSERT INTO settings (key, value) VALUES (?, ?)', ['logo', '/assets/images/logo.png']);
  }

  // 初始化资源分类
  const categoriesCount = getOne('SELECT COUNT(*) as count FROM resource_categories');
  if (!categoriesCount || categoriesCount.count === 0) {
    const now = new Date().toISOString();
    const categories = [
      { code: 'policy', name: '政策法规', icon: 'layui-icon-file', description: '政府政策、法律法规相关资讯' },
      { code: 'economy', name: '经济动态', icon: 'layui-icon-chart', description: '经济发展、市场动态相关资讯' },
      { code: 'society', name: '社会民生', icon: 'layui-icon-group', description: '社会事件、民生热点相关资讯' },
      { code: 'tech', name: '科技创新', icon: 'layui-icon-engine', description: '科技发展、创新成果相关资讯' },
      { code: 'enterprise', name: '企业舆情', icon: 'layui-icon-website', description: '企业动态、品牌舆情相关资讯' },
      { code: 'emergency', name: '突发事件', icon: 'layui-icon-notice', description: '突发事件、应急响应相关资讯' },
      { code: 'culture', name: '文化教育', icon: 'layui-icon-read', description: '文化活动、教育资讯相关内容' },
      { code: 'environment', name: '生态环境', icon: 'layui-icon-tree', description: '环境保护、生态建设相关资讯' }
    ];
    categories.forEach((cat, index) => {
      runQuery('INSERT INTO resource_categories (id, name, code, icon, description, sort_order, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        [uuidv4(), cat.name, cat.code, cat.icon, cat.description, index + 1, now, now]);
    });
    console.log('资源分类初始化完成');
  }

  // 初始化资源标签
  const tagsCount = getOne('SELECT COUNT(*) as count FROM resource_tags');
  if (!tagsCount || tagsCount.count === 0) {
    const now = new Date().toISOString();
    const tags = [
      { name: '重要', color: '#f5222d' },
      { name: '热点', color: '#fa541c' },
      { name: '正面', color: '#52c41a' },
      { name: '负面', color: '#ff4d4f' },
      { name: '中性', color: '#1890ff' },
      { name: '待处理', color: '#faad14' },
      { name: '已处理', color: '#52c41a' },
      { name: '关注', color: '#722ed1' }
    ];
    tags.forEach(tag => {
      runQuery('INSERT INTO resource_tags (id, name, color, created_at) VALUES (?, ?, ?, ?)',
        [uuidv4(), tag.name, tag.color, now]);
    });
    console.log('资源标签初始化完成');
  }

  // 初始化示例舆情报告数据
  const reportsCount = getOne('SELECT COUNT(*) as count FROM reports');
  if (!reportsCount || reportsCount.count === 0) {
    const now = new Date().toISOString();
    const sampleReports = [
      {
        title: '2024年度政策解读：数字经济发展新机遇',
        summary: '本报告深入分析了国家数字经济政策的最新动态，解读了对企业发展的积极影响和创新机遇。',
        content: '随着国家数字经济战略的深入推进，各地政府纷纷出台支持政策，为企业数字化转型提供了良好的发展环境。本报告从政策背景、主要内容、实施效果等方面进行了全面分析，指出数字经济将成为推动经济高质量发展的重要引擎。企业应抓住机遇，加快数字化转型步伐，提升核心竞争力。',
        status: 'published'
      },
      {
        title: '民生热点：城市公共服务满意度调查报告',
        summary: '针对城市居民对公共服务的满意度进行了全面调查，涵盖交通、医疗、教育等多个领域。',
        content: '本次调查覆盖全市10个区县，收集有效问卷5000余份。调查结果显示，市民对公共交通服务满意度达85%，医疗服务满意度为78%，教育服务满意度为82%。报告同时指出了存在的问题和改进建议，为政府决策提供参考依据。',
        status: 'published'
      },
      {
        title: '经济动态：第三季度区域经济运行分析',
        summary: '分析第三季度区域经济运行态势，GDP增长稳中向好，产业结构持续优化。',
        content: '第三季度，全区实现地区生产总值同比增长6.8%，高于全国平均水平。其中，第一产业增长3.2%，第二产业增长7.5%，第三产业增长6.2%。工业生产保持平稳，服务业发展势头良好，消费市场持续回暖。报告预测第四季度经济将继续保持稳定增长态势。',
        status: 'published'
      },
      {
        title: '社会事件舆情分析：网络热点事件追踪',
        summary: '对近期网络热点社会事件进行舆情监测和分析，评估舆论走向和社会影响。',
        content: '本报告对近一周内的网络热点事件进行了全面监测，包括事件起因、传播路径、舆论反应、官方回应等方面。通过大数据分析，识别出舆情风险点，并提出了相应的应对建议。报告强调了及时、透明、有效的信息公开对于化解舆情危机的重要性。',
        status: 'published'
      },
      {
        title: '舆情分析报告：企业品牌形象监测月报',
        summary: '对重点企业品牌形象进行月度监测，分析正面和负面舆情分布情况。',
        content: '本月监测了50家重点企业的网络舆情，共采集相关信息12万余条。整体来看，正面舆情占比65%，中性舆情占比28%，负面舆情占比7%。报告详细分析了各企业的舆情特点，并针对负面舆情提出了改进建议。建议企业加强品牌建设，积极回应社会关切。',
        status: 'published'
      },
      {
        title: '政策解读：营商环境优化措施解析',
        summary: '解读最新营商环境优化政策，分析对企业经营的积极影响和发展机遇。',
        content: '近期，政府出台了一系列优化营商环境的政策措施，包括简化审批流程、降低企业成本、加强知识产权保护等。本报告对这些政策进行了详细解读，分析了政策实施后对企业的积极影响。报告指出，良好的营商环境将吸引更多投资，促进经济持续健康发展。',
        status: 'published'
      }
    ];

    sampleReports.forEach(report => {
      runQuery('INSERT INTO reports (id, title, summary, content, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [uuidv4(), report.title, report.summary, report.content, report.status, now, now]);
    });
    console.log('示例舆情报告数据已创建');
  }

  saveDatabase();
  console.log('数据库初始化完成');
}

// 中间件配置
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.use(session({
  secret: 'gov-enterprise-sentiment-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: { 
    secure: false,
    maxAge: 24 * 60 * 60 * 1000 // 24小时
  }
}));

// 文件上传配置
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, 'uploads'));
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `${Date.now()}-${uuidv4()}${ext}`);
  }
});
const upload = multer({ storage });

// 认证中间件
const authMiddleware = (req, res, next) => {
  if (req.session && req.session.user) {
    next();
  } else {
    res.status(401).json({ code: 401, msg: '未登录或登录已过期' });
  }
};

// 管理员权限中间件
const adminMiddleware = (req, res, next) => {
  if (req.session && req.session.user && req.session.user.role === 'admin') {
    next();
  } else {
    res.status(403).json({ code: 403, msg: '权限不足' });
  }
};

// ==================== API 路由 ====================

// 登录
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  
  if (!username || !password) {
    return res.json({ code: 1, msg: '用户名和密码不能为空' });
  }

  const user = getOne('SELECT * FROM users WHERE username = ? AND status = 1', [username]);
  
  if (!user) {
    return res.json({ code: 1, msg: '用户不存在或已被禁用' });
  }

  if (!bcrypt.compareSync(password, user.password)) {
    return res.json({ code: 1, msg: '密码错误' });
  }

  req.session.user = {
    id: user.id,
    username: user.username,
    role: user.role
  };

  res.json({ 
    code: 0, 
    msg: '登录成功',
    data: {
      id: user.id,
      username: user.username,
      role: user.role
    }
  });
});

// 退出登录
app.post('/api/logout', (req, res) => {
  req.session.destroy();
  res.json({ code: 0, msg: '退出成功' });
});

// 获取当前用户信息
app.get('/api/user/info', authMiddleware, (req, res) => {
  const settings = {};
  getAll('SELECT key, value FROM settings').forEach(row => {
    settings[row.key] = row.value;
  });
  
  res.json({ 
    code: 0, 
    data: {
      user: req.session.user,
      settings
    }
  });
});

// ==================== 用户管理 API ====================

// 获取用户列表
app.get('/api/users', authMiddleware, adminMiddleware, (req, res) => {
  const { page = 1, limit = 10, username } = req.query;
  const offset = (page - 1) * limit;
  
  let sql = 'SELECT id, username, role, status, created_at, updated_at FROM users WHERE 1=1';
  let countSql = 'SELECT COUNT(*) as total FROM users WHERE 1=1';
  const params = [];
  
  if (username) {
    sql += ' AND username LIKE ?';
    countSql += ' AND username LIKE ?';
    params.push(`%${username}%`);
  }
  
  const totalResult = getOne(countSql, params);
  const total = totalResult ? totalResult.total : 0;
  sql += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
  const users = getAll(sql, [...params, parseInt(limit), parseInt(offset)]);
  
  res.json({ code: 0, data: users, count: total });
});

// 添加用户
app.post('/api/users', authMiddleware, adminMiddleware, (req, res) => {
  const { username, password, role = 'user' } = req.body;
  
  if (!username || !password) {
    return res.json({ code: 1, msg: '用户名和密码不能为空' });
  }

  const existing = getOne('SELECT id FROM users WHERE username = ?', [username]);
  if (existing) {
    return res.json({ code: 1, msg: '用户名已存在' });
  }

  const hashedPassword = bcrypt.hashSync(password, 10);
  const id = uuidv4();
  const now = new Date().toISOString();
  
  runQuery('INSERT INTO users (id, username, password, role, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)',
    [id, username, hashedPassword, role, now, now]);
  
  res.json({ code: 0, msg: '添加成功' });
});

// 更新用户
app.put('/api/users/:id', authMiddleware, adminMiddleware, (req, res) => {
  const { id } = req.params;
  const { username, password, role, status } = req.body;
  
  const user = getOne('SELECT * FROM users WHERE id = ?', [id]);
  if (!user) {
    return res.json({ code: 1, msg: '用户不存在' });
  }

  const now = new Date().toISOString();
  let sql = 'UPDATE users SET updated_at = ?';
  const params = [now];
  
  if (username) {
    sql += ', username = ?';
    params.push(username);
  }
  if (password) {
    sql += ', password = ?';
    params.push(bcrypt.hashSync(password, 10));
  }
  if (role) {
    sql += ', role = ?';
    params.push(role);
  }
  if (status !== undefined) {
    sql += ', status = ?';
    params.push(status);
  }
  
  sql += ' WHERE id = ?';
  params.push(id);
  
  runQuery(sql, params);
  res.json({ code: 0, msg: '更新成功' });
});

// 删除用户
app.delete('/api/users/:id', authMiddleware, adminMiddleware, (req, res) => {
  const { id } = req.params;
  
  const user = getOne('SELECT * FROM users WHERE id = ?', [id]);
  if (!user) {
    return res.json({ code: 1, msg: '用户不存在' });
  }
  
  if (user.role === 'admin') {
    const adminCountResult = getOne('SELECT COUNT(*) as count FROM users WHERE role = ?', ['admin']);
    if (adminCountResult && adminCountResult.count <= 1) {
      return res.json({ code: 1, msg: '不能删除最后一个管理员' });
    }
  }
  
  runQuery('DELETE FROM users WHERE id = ?', [id]);
  res.json({ code: 0, msg: '删除成功' });
});

// ==================== 角色管理 API ====================

// 获取角色列表
app.get('/api/roles', authMiddleware, adminMiddleware, (req, res) => {
  const roles = getAll('SELECT * FROM roles ORDER BY created_at');
  res.json({ code: 0, data: roles });
});

// 添加角色
app.post('/api/roles', authMiddleware, adminMiddleware, (req, res) => {
  const { name, description, permissions = [] } = req.body;
  
  if (!name) {
    return res.json({ code: 1, msg: '角色名称不能为空' });
  }

  const existing = getOne('SELECT id FROM roles WHERE name = ?', [name]);
  if (existing) {
    return res.json({ code: 1, msg: '角色名称已存在' });
  }

  const id = uuidv4();
  const now = new Date().toISOString();
  runQuery('INSERT INTO roles (id, name, description, permissions, created_at) VALUES (?, ?, ?, ?, ?)',
    [id, name, description, JSON.stringify(permissions), now]);
  
  res.json({ code: 0, msg: '添加成功' });
});

// 更新角色
app.put('/api/roles/:id', authMiddleware, adminMiddleware, (req, res) => {
  const { id } = req.params;
  const { name, description, permissions } = req.body;
  
  const role = getOne('SELECT * FROM roles WHERE id = ?', [id]);
  if (!role) {
    return res.json({ code: 1, msg: '角色不存在' });
  }

  runQuery('UPDATE roles SET name = ?, description = ?, permissions = ? WHERE id = ?',
    [name || role.name, description || role.description, permissions ? JSON.stringify(permissions) : role.permissions, id]);
  
  res.json({ code: 0, msg: '更新成功' });
});

// 删除角色
app.delete('/api/roles/:id', authMiddleware, adminMiddleware, (req, res) => {
  const { id } = req.params;
  
  const role = getOne('SELECT * FROM roles WHERE id = ?', [id]);
  if (!role) {
    return res.json({ code: 1, msg: '角色不存在' });
  }
  
  if (role.name === 'admin' || role.name === 'user') {
    return res.json({ code: 1, msg: '系统内置角色不能删除' });
  }
  
  runQuery('DELETE FROM roles WHERE id = ?', [id]);
  res.json({ code: 0, msg: '删除成功' });
});

// ==================== 系统设置 API ====================

// 获取系统设置
app.get('/api/settings', authMiddleware, (req, res) => {
  const settings = {};
  getAll('SELECT key, value FROM settings').forEach(row => {
    settings[row.key] = row.value;
  });
  res.json({ code: 0, data: settings });
});

// 更新系统设置
app.put('/api/settings', authMiddleware, adminMiddleware, (req, res) => {
  const { app_name, logo } = req.body;
  const now = new Date().toISOString();
  
  if (app_name) {
    runQuery('UPDATE settings SET value = ?, updated_at = ? WHERE key = ?', [app_name, now, 'app_name']);
  }
  if (logo) {
    runQuery('UPDATE settings SET value = ?, updated_at = ? WHERE key = ?', [logo, now, 'logo']);
  }
  
  res.json({ code: 0, msg: '设置已更新' });
});

// 上传Logo
app.post('/api/upload/logo', authMiddleware, adminMiddleware, upload.single('file'), (req, res) => {
  if (!req.file) {
    return res.json({ code: 1, msg: '请选择文件' });
  }
  
  const logoPath = `/uploads/${req.file.filename}`;
  const now = new Date().toISOString();
  runQuery('UPDATE settings SET value = ?, updated_at = ? WHERE key = ?', [logoPath, now, 'logo']);
  
  res.json({ code: 0, msg: '上传成功', data: { url: logoPath } });
});

// ==================== 报告管理 API ====================

// 获取报告列表
app.get('/api/reports', authMiddleware, (req, res) => {
  const { page = 1, limit = 10, title, status } = req.query;
  const offset = (page - 1) * limit;
  
  let sql = 'SELECT * FROM reports WHERE 1=1';
  let countSql = 'SELECT COUNT(*) as total FROM reports WHERE 1=1';
  const params = [];
  
  if (title) {
    sql += ' AND title LIKE ?';
    countSql += ' AND title LIKE ?';
    params.push(`%${title}%`);
  }
  if (status) {
    sql += ' AND status = ?';
    countSql += ' AND status = ?';
    params.push(status);
  }
  
  const totalResult = getOne(countSql, params);
  const total = totalResult ? totalResult.total : 0;
  sql += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
  const reports = getAll(sql, [...params, parseInt(limit), parseInt(offset)]);
  
  res.json({ code: 0, data: reports, count: total });
});

// 获取最新报告
app.get('/api/reports/latest', authMiddleware, (req, res) => {
  const reports = getAll('SELECT * FROM reports WHERE status = ? ORDER BY created_at DESC LIMIT 5', ['published']);
  res.json({ code: 0, data: reports });
});

// 获取报告详情
app.get('/api/reports/:id', authMiddleware, (req, res) => {
  const { id } = req.params;
  const report = getOne('SELECT * FROM reports WHERE id = ?', [id]);
  
  if (!report) {
    return res.json({ code: 1, msg: '报告不存在' });
  }
  
  res.json({ code: 0, data: report });
});

// 添加报告
app.post('/api/reports', authMiddleware, adminMiddleware, (req, res) => {
  const { title, content, summary, status = 'draft' } = req.body;
  
  if (!title) {
    return res.json({ code: 1, msg: '报告标题不能为空' });
  }

  const id = uuidv4();
  const now = new Date().toISOString();
  runQuery('INSERT INTO reports (id, title, content, summary, status, created_by, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
    [id, title, content || '', summary || '', status, req.session.user.id, now, now]);
  
  res.json({ code: 0, msg: '添加成功', data: { id } });
});

// 更新报告
app.put('/api/reports/:id', authMiddleware, adminMiddleware, (req, res) => {
  const { id } = req.params;
  const { title, content, summary, status } = req.body;
  
  const report = getOne('SELECT * FROM reports WHERE id = ?', [id]);
  if (!report) {
    return res.json({ code: 1, msg: '报告不存在' });
  }

  const now = new Date().toISOString();
  runQuery('UPDATE reports SET title = ?, content = ?, summary = ?, status = ?, updated_at = ? WHERE id = ?',
    [title || report.title, content !== undefined ? content : report.content, summary !== undefined ? summary : report.summary, status || report.status, now, id]);
  
  res.json({ code: 0, msg: '更新成功' });
});

// 删除报告
app.delete('/api/reports/:id', authMiddleware, adminMiddleware, (req, res) => {
  const { id } = req.params;
  
  const report = getOne('SELECT * FROM reports WHERE id = ?', [id]);
  if (!report) {
    return res.json({ code: 1, msg: '报告不存在' });
  }
  
  runQuery('DELETE FROM reports WHERE id = ?', [id]);
  res.json({ code: 0, msg: '删除成功' });
});

// 批量删除报告
app.post('/api/reports/batch-delete', authMiddleware, adminMiddleware, (req, res) => {
  const { ids } = req.body;
  
  if (!ids || !Array.isArray(ids) || ids.length === 0) {
    return res.json({ code: 1, msg: '请选择要删除的报告' });
  }
  
  const placeholders = ids.map(() => '?').join(',');
  runQuery(`DELETE FROM reports WHERE id IN (${placeholders})`, ids);
  
  res.json({ code: 0, msg: `成功删除 ${ids.length} 条报告` });
});

// 批量发布报告
app.post('/api/reports/batch-publish', authMiddleware, adminMiddleware, (req, res) => {
  const { ids } = req.body;
  
  if (!ids || !Array.isArray(ids) || ids.length === 0) {
    return res.json({ code: 1, msg: '请选择要发布的报告' });
  }
  
  const now = new Date().toISOString();
  const placeholders = ids.map(() => '?').join(',');
  runQuery(`UPDATE reports SET status = 'published', updated_at = ? WHERE id IN (${placeholders})`, [now, ...ids]);
  
  res.json({ code: 0, msg: `成功发布 ${ids.length} 条报告` });
});

// ==================== 仪表盘数据 API ====================

app.get('/api/dashboard/stats', authMiddleware, (req, res) => {
  const userCountResult = getOne('SELECT COUNT(*) as count FROM users');
  const reportCountResult = getOne('SELECT COUNT(*) as count FROM reports');
  const publishedCountResult = getOne('SELECT COUNT(*) as count FROM reports WHERE status = ?', ['published']);
  
  res.json({
    code: 0,
    data: {
      userCount: userCountResult ? userCountResult.count : 0,
      reportCount: reportCountResult ? reportCountResult.count : 0,
      publishedCount: publishedCountResult ? publishedCountResult.count : 0,
      todayVisits: Math.floor(Math.random() * 1000) + 100 // 模拟数据
    }
  });
});

// ==================== 数据抓取 API ====================

/**
 * 搜索新闻 - 单关键字搜索
 * GET /api/crawler/search?keyword=关键字&page=1
 */
app.get('/api/crawler/search', authMiddleware, async (req, res) => {
  try {
    const { keyword, page = 1 } = req.query;
    
    if (!keyword) {
      return res.json({ code: 1, msg: '关键字不能为空' });
    }

    console.log(`[Crawler] 开始搜索: ${keyword}, 页码: ${page}`);
    const result = await search(keyword, { page: parseInt(page) });
    
    res.json({
      code: 0,
      msg: '搜索成功',
      data: result
    });
  } catch (error) {
    console.error('[Crawler] 搜索失败:', error.message);
    res.json({ code: 1, msg: `搜索失败: ${error.message}` });
  }
});

/**
 * 批量搜索新闻 - 多关键字搜索
 * POST /api/crawler/batch-search
 * Body: { keywords: ['关键字1', '关键字2'], delay: 2000 }
 */
app.post('/api/crawler/batch-search', authMiddleware, async (req, res) => {
  try {
    const { keywords, delay = 2000 } = req.body;
    
    if (!keywords || !Array.isArray(keywords) || keywords.length === 0) {
      return res.json({ code: 1, msg: '关键字列表不能为空' });
    }

    if (keywords.length > 10) {
      return res.json({ code: 1, msg: '单次最多支持10个关键字' });
    }

    console.log(`[Crawler] 批量搜索: ${keywords.join(', ')}`);
    const results = await batchSearch(keywords, { delay: parseInt(delay) });
    
    res.json({
      code: 0,
      msg: '批量搜索完成',
      data: results
    });
  } catch (error) {
    console.error('[Crawler] 批量搜索失败:', error.message);
    res.json({ code: 1, msg: `批量搜索失败: ${error.message}` });
  }
});

/**
 * 多页搜索 - 获取多页数据（百度新闻）
 * GET /api/crawler/search-pages?keyword=关键字&pages=3
 */
app.get('/api/crawler/search-pages', authMiddleware, async (req, res) => {
  try {
    const { keyword, pages = 3 } = req.query;
    
    if (!keyword) {
      return res.json({ code: 1, msg: '关键字不能为空' });
    }

    const pageCount = Math.min(parseInt(pages) || 3, 5); // 最多5页
    console.log(`[Crawler] 百度新闻搜索: ${keyword}, 页数: ${pageCount}`);
    
    const result = await searchMultiplePages(keyword, pageCount);
    
    // 返回 items 数组，前端期望 data 是数组
    res.json({
      code: 0,
      msg: '搜索成功',
      data: result.items || [],
      total: result.total || 0
    });
  } catch (error) {
    console.error('[Crawler] 百度新闻搜索失败:', error.message);
    res.json({ code: 1, msg: `搜索失败: ${error.message}` });
  }
});

/**
 * 搜狗资讯搜索
 * GET /api/crawler/search-sogou?keyword=关键字&pages=2
 */
app.get('/api/crawler/search-sogou', authMiddleware, async (req, res) => {
  try {
    const { keyword, pages = 2 } = req.query;
    
    if (!keyword) {
      return res.json({ code: 1, msg: '关键字不能为空' });
    }

    console.log(`[Crawler] 搜狗资讯搜索: ${keyword}`);
    
    const items = [];
    const pageCount = Math.min(parseInt(pages) || 2, 3);
    
    for (let page = 1; page <= pageCount; page++) {
      const url = `https://news.sogou.com/news?query=${encodeURIComponent(keyword)}&page=${page}`;
      
      try {
        const response = await axios.get(url, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'zh-CN,zh;q=0.9'
          },
          timeout: 15000,
          responseType: 'arraybuffer'
        });
        
        const html = iconv.decode(Buffer.from(response.data), 'utf-8');
        const $ = cheerio.load(html);
        
        $('.news-list li, .results li, .vrwrap').each(function() {
          const $item = $(this);
          const title = $item.find('h3 a, .news-title a').first().text().trim();
          const link = $item.find('h3 a, .news-title a').first().attr('href');
          const summary = $item.find('.news-txt, .str-text, p').first().text().trim();
          const source = $item.find('.news-from span, .news-source').first().text().trim();
          const time = $item.find('.news-from span:last, .news-time').text().trim();
          
          if (title && link) {
            items.push({
              title: title,
              url: link.startsWith('http') ? link : 'https://news.sogou.com' + link,
              summary: summary.substring(0, 200),
              source: source || '搜狗资讯',
              publishTime: time,
              cover: ''
            });
          }
        });
      } catch (e) {
        console.log(`[Crawler] 搜狗第${page}页采集失败:`, e.message);
      }
    }
    
    res.json({
      code: 0,
      msg: '搜索成功',
      data: items,
      total: items.length
    });
  } catch (error) {
    console.error('[Crawler] 搜狗资讯搜索失败:', error.message);
    res.json({ code: 1, msg: `搜索失败: ${error.message}` });
  }
});

/**
 * 今日头条搜索
 * GET /api/crawler/search-toutiao?keyword=关键字&pages=2
 */
app.get('/api/crawler/search-toutiao', authMiddleware, async (req, res) => {
  try {
    const { keyword, pages = 2 } = req.query;
    
    if (!keyword) {
      return res.json({ code: 1, msg: '关键字不能为空' });
    }

    console.log(`[Crawler] 今日头条搜索: ${keyword}`);
    
    const items = [];
    const pageCount = Math.min(parseInt(pages) || 2, 3);
    
    for (let page = 0; page < pageCount; page++) {
      const url = `https://www.toutiao.com/api/search/content/?keyword=${encodeURIComponent(keyword)}&offset=${page * 20}&count=20&cur_tab=1`;
      
      try {
        const response = await axios.get(url, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'application/json',
            'Referer': 'https://www.toutiao.com/'
          },
          timeout: 15000
        });
        
        if (response.data && response.data.data) {
          response.data.data.forEach(item => {
            if (item.title) {
              items.push({
                title: item.title,
                url: item.article_url || item.display_url || `https://www.toutiao.com/article/${item.item_id}/`,
                summary: item.abstract || item.description || '',
                source: item.source || item.media_name || '今日头条',
                publishTime: item.datetime || '',
                cover: item.image_url || (item.image_list && item.image_list[0] && item.image_list[0].url) || ''
              });
            }
          });
        }
      } catch (e) {
        console.log(`[Crawler] 头条第${page + 1}页采集失败:`, e.message);
      }
    }
    
    res.json({
      code: 0,
      msg: '搜索成功',
      data: items,
      total: items.length
    });
  } catch (error) {
    console.error('[Crawler] 今日头条搜索失败:', error.message);
    res.json({ code: 1, msg: `搜索失败: ${error.message}` });
  }
});

/**
 * 微博热搜
 * GET /api/crawler/search-weibo?keyword=关键字&pages=2
 */
app.get('/api/crawler/search-weibo', authMiddleware, async (req, res) => {
  try {
    const { keyword, pages = 2 } = req.query;
    
    if (!keyword) {
      return res.json({ code: 1, msg: '关键字不能为空' });
    }

    console.log(`[Crawler] 微博搜索: ${keyword}`);
    
    const items = [];
    const pageCount = Math.min(parseInt(pages) || 2, 3);
    
    for (let page = 1; page <= pageCount; page++) {
      const url = `https://s.weibo.com/weibo?q=${encodeURIComponent(keyword)}&page=${page}`;
      
      try {
        const response = await axios.get(url, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Cookie': 'SUB=_2A25placeholder'
          },
          timeout: 15000
        });
        
        const $ = cheerio.load(response.data);
        
        $('.card-wrap[action-type="feed_list_item"], .card').each(function() {
          const $item = $(this);
          const content = $item.find('.txt, .content p').first().text().trim();
          const name = $item.find('.name, .info .name').first().text().trim();
          const time = $item.find('.from a:first, .time').first().text().trim();
          const link = $item.find('.from a:first').attr('href');
          
          if (content) {
            items.push({
              title: content.substring(0, 80) + (content.length > 80 ? '...' : ''),
              url: link ? (link.startsWith('http') ? link : 'https://weibo.com' + link) : 'https://weibo.com',
              summary: content.substring(0, 200),
              source: name || '微博用户',
              publishTime: time,
              cover: ''
            });
          }
        });
      } catch (e) {
        console.log(`[Crawler] 微博第${page}页采集失败:`, e.message);
      }
    }
    
    res.json({
      code: 0,
      msg: '搜索成功',
      data: items,
      total: items.length
    });
  } catch (error) {
    console.error('[Crawler] 微博搜索失败:', error.message);
    res.json({ code: 1, msg: `搜索失败: ${error.message}` });
  }
});

/**
 * 知乎热榜搜索
 * GET /api/crawler/search-zhihu?keyword=关键字&pages=2
 */
app.get('/api/crawler/search-zhihu', authMiddleware, async (req, res) => {
  try {
    const { keyword, pages = 2 } = req.query;
    
    if (!keyword) {
      return res.json({ code: 1, msg: '关键字不能为空' });
    }

    console.log(`[Crawler] 知乎搜索: ${keyword}`);
    
    const items = [];
    const pageCount = Math.min(parseInt(pages) || 2, 3);
    
    for (let page = 0; page < pageCount; page++) {
      const url = `https://www.zhihu.com/api/v4/search_v3?t=general&q=${encodeURIComponent(keyword)}&offset=${page * 20}&limit=20`;
      
      try {
        const response = await axios.get(url, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'application/json',
            'Referer': 'https://www.zhihu.com/'
          },
          timeout: 15000
        });
        
        if (response.data && response.data.data) {
          response.data.data.forEach(item => {
            const obj = item.object || item;
            if (obj.question || obj.title) {
              items.push({
                title: obj.question?.title || obj.title || '',
                url: obj.url || `https://www.zhihu.com/question/${obj.question?.id || obj.id}`,
                summary: obj.excerpt || obj.content || '',
                source: obj.author?.name || '知乎用户',
                publishTime: obj.created_time ? new Date(obj.created_time * 1000).toLocaleDateString() : '',
                cover: ''
              });
            }
          });
        }
      } catch (e) {
        console.log(`[Crawler] 知乎第${page + 1}页采集失败:`, e.message);
      }
    }
    
    res.json({
      code: 0,
      msg: '搜索成功',
      data: items,
      total: items.length
    });
  } catch (error) {
    console.error('[Crawler] 知乎搜索失败:', error.message);
    res.json({ code: 1, msg: `搜索失败: ${error.message}` });
  }
});

/**
 * 微信公众号搜索
 * GET /api/crawler/search-wechat?keyword=关键字&pages=2
 */
app.get('/api/crawler/search-wechat', authMiddleware, async (req, res) => {
  try {
    const { keyword, pages = 2 } = req.query;
    
    if (!keyword) {
      return res.json({ code: 1, msg: '关键字不能为空' });
    }

    console.log(`[Crawler] 微信公众号搜索: ${keyword}`);
    
    const items = [];
    const pageCount = Math.min(parseInt(pages) || 2, 3);
    
    // 使用搜狗微信搜索
    for (let page = 1; page <= pageCount; page++) {
      const url = `https://weixin.sogou.com/weixin?type=2&query=${encodeURIComponent(keyword)}&page=${page}`;
      
      try {
        const response = await axios.get(url, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
          },
          timeout: 15000
        });
        
        const $ = cheerio.load(response.data);
        
        $('.news-list li, .news-box li').each(function() {
          const $item = $(this);
          const title = $item.find('h3 a, .txt-box h3 a').first().text().trim();
          const link = $item.find('h3 a, .txt-box h3 a').first().attr('href');
          const summary = $item.find('.txt-info, p.txt-info').first().text().trim();
          const source = $item.find('.account, .s-p a').first().text().trim();
          const time = $item.find('.s-p, .s2').text().trim();
          const cover = $item.find('img').first().attr('src');
          
          if (title && link) {
            items.push({
              title: title,
              url: link.startsWith('http') ? link : 'https://weixin.sogou.com' + link,
              summary: summary.substring(0, 200),
              source: source || '微信公众号',
              publishTime: time,
              cover: cover || ''
            });
          }
        });
      } catch (e) {
        console.log(`[Crawler] 微信第${page}页采集失败:`, e.message);
      }
    }
    
    res.json({
      code: 0,
      msg: '搜索成功',
      data: items,
      total: items.length
    });
  } catch (error) {
    console.error('[Crawler] 微信公众号搜索失败:', error.message);
    res.json({ code: 1, msg: `搜索失败: ${error.message}` });
  }
});

/**
 * 保存抓取结果到数据库
 * POST /api/crawler/save
 * Body: { keyword: '关键字', items: [...] }
 */
app.post('/api/crawler/save', authMiddleware, async (req, res) => {
  try {
    const { keyword, items } = req.body;
    
    if (!keyword || !items || !Array.isArray(items)) {
      return res.json({ code: 1, msg: '参数错误' });
    }

    // 创建抓取记录表（如果不存在）
    db.run(`
      CREATE TABLE IF NOT EXISTS crawl_records (
        id TEXT PRIMARY KEY,
        keyword TEXT NOT NULL,
        title TEXT,
        summary TEXT,
        cover TEXT,
        url TEXT,
        source TEXT,
        publish_time TEXT,
        crawl_time DATETIME DEFAULT CURRENT_TIMESTAMP,
        created_by TEXT
      )
    `);
    saveDatabase();

    const now = new Date().toISOString();
    let savedCount = 0;

    for (const item of items) {
      const id = uuidv4();
      runQuery(`
        INSERT INTO crawl_records (id, keyword, title, summary, cover, url, source, publish_time, crawl_time, created_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        id,
        keyword,
        item.title || '',
        item.summary || '',
        item.cover || '',
        item.url || '',
        item.source || '',
        item.publishTime || '',
        now,
        req.session.user.id
      ]);
      savedCount++;
    }

    res.json({
      code: 0,
      msg: `成功保存 ${savedCount} 条记录`,
      data: { savedCount }
    });
  } catch (error) {
    console.error('[Crawler] 保存失败:', error.message);
    res.json({ code: 1, msg: `保存失败: ${error.message}` });
  }
});

/**
 * 获取抓取历史记录
 * GET /api/crawler/records?keyword=关键字&page=1&limit=20
 */
app.get('/api/crawler/records', authMiddleware, async (req, res) => {
  try {
    const { keyword, page = 1, limit = 20 } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);

    // 确保表存在
    db.run(`
      CREATE TABLE IF NOT EXISTS crawl_records (
        id TEXT PRIMARY KEY,
        keyword TEXT NOT NULL,
        title TEXT,
        summary TEXT,
        cover TEXT,
        url TEXT,
        source TEXT,
        publish_time TEXT,
        crawl_time DATETIME DEFAULT CURRENT_TIMESTAMP,
        created_by TEXT
      )
    `);

    let sql = 'SELECT * FROM crawl_records WHERE 1=1';
    let countSql = 'SELECT COUNT(*) as total FROM crawl_records WHERE 1=1';
    const params = [];

    if (keyword) {
      sql += ' AND keyword LIKE ?';
      countSql += ' AND keyword LIKE ?';
      params.push(`%${keyword}%`);
    }

    const totalResult = getOne(countSql, params);
    const total = totalResult ? totalResult.total : 0;

    sql += ' ORDER BY crawl_time DESC LIMIT ? OFFSET ?';
    const records = getAll(sql, [...params, parseInt(limit), offset]);

    res.json({
      code: 0,
      data: records,
      count: total
    });
  } catch (error) {
    console.error('[Crawler] 获取记录失败:', error.message);
    res.json({ code: 1, msg: `获取记录失败: ${error.message}` });
  }
});

/**
 * 删除抓取记录
 * DELETE /api/crawler/records/:id
 */
app.delete('/api/crawler/records/:id', authMiddleware, adminMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    
    const record = getOne('SELECT * FROM crawl_records WHERE id = ?', [id]);
    if (!record) {
      return res.json({ code: 1, msg: '记录不存在' });
    }

    runQuery('DELETE FROM crawl_records WHERE id = ?', [id]);
    res.json({ code: 0, msg: '删除成功' });
  } catch (error) {
    console.error('[Crawler] 删除失败:', error.message);
    res.json({ code: 1, msg: `删除失败: ${error.message}` });
  }
});

/**
 * 清空指定关键字的抓取记录
 * DELETE /api/crawler/records/keyword/:keyword
 */
app.delete('/api/crawler/records/keyword/:keyword', authMiddleware, adminMiddleware, async (req, res) => {
  try {
    const { keyword } = req.params;
    
    runQuery('DELETE FROM crawl_records WHERE keyword = ?', [keyword]);
    res.json({ code: 0, msg: '清空成功' });
  } catch (error) {
    console.error('[Crawler] 清空失败:', error.message);
    res.json({ code: 1, msg: `清空失败: ${error.message}` });
  }
});

/**
 * 深度采集 - 抓取文章详情内容
 * POST /api/crawler/deep
 * Body: { url: '文章URL' }
 */
app.post('/api/crawler/deep', authMiddleware, async (req, res) => {
  try {
    const { url } = req.body;
    
    if (!url) {
      return res.json({ code: 1, msg: 'URL不能为空' });
    }

    console.log('[DeepCrawl] 开始深度采集:', url);

    // 请求头配置
    const headers = {
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
      'Accept-Language': 'zh-CN,zh;q=0.9',
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Cache-Control': 'no-cache'
    };

    // 发送请求
    const response = await axios.get(url, {
      headers,
      timeout: 15000,
      responseType: 'arraybuffer',
      maxRedirects: 5
    });

    // 检测编码并转换
    let html = '';
    const contentType = response.headers['content-type'] || '';
    if (contentType.includes('gbk') || contentType.includes('gb2312')) {
      html = iconv.decode(Buffer.from(response.data), 'gbk');
    } else {
      html = iconv.decode(Buffer.from(response.data), 'utf-8');
    }

    // 解析HTML
    const $ = cheerio.load(html);

    // 移除脚本和样式
    $('script, style, iframe, noscript').remove();

    // 提取标题
    let title = $('h1').first().text().trim() ||
                $('title').text().trim() ||
                $('meta[property="og:title"]').attr('content') || '';

    // 提取来源
    let source = $('meta[name="source"]').attr('content') ||
                 $('meta[property="og:site_name"]').attr('content') ||
                 $('a[rel="author"]').text().trim() ||
                 '';

    // 提取发布时间
    let publishTime = $('meta[property="article:published_time"]').attr('content') ||
                      $('meta[name="publishdate"]').attr('content') ||
                      $('time').first().attr('datetime') ||
                      $('time').first().text().trim() ||
                      $('.time, .date, .publish-time, .article-time, .post-time').first().text().trim() ||
                      '';

    // 提取正文内容
    let content = '';
    
    // 常见的正文容器选择器
    const contentSelectors = [
      'article',
      '.article-content',
      '.article-body',
      '.post-content',
      '.entry-content',
      '.content-article',
      '.news-content',
      '.detail-content',
      '.main-content',
      '#article-content',
      '#content',
      '.text',
      '.article'
    ];

    for (const selector of contentSelectors) {
      const el = $(selector);
      if (el.length && el.text().trim().length > 100) {
        content = el.html();
        break;
      }
    }

    // 如果没找到，尝试获取body中最长的文本块
    if (!content) {
      let maxLength = 0;
      $('div, section').each(function() {
        const text = $(this).text().trim();
        if (text.length > maxLength && text.length > 200) {
          maxLength = text.length;
          content = $(this).html();
        }
      });
    }

    // 清理内容
    if (content) {
      const $content = cheerio.load(content);
      $content('script, style, iframe, noscript, .ad, .advertisement, .share, .comment').remove();
      
      // 转换为纯文本段落
      let cleanContent = '';
      $content('p, div, h2, h3, h4').each(function() {
        const text = $content(this).text().trim();
        if (text.length > 10) {
          cleanContent += '<p>' + text + '</p>';
        }
      });
      
      content = cleanContent || $content.text().trim();
    }

    console.log('[DeepCrawl] 采集成功:', title.substring(0, 50));

    res.json({
      code: 0,
      msg: '深度采集成功',
      data: {
        title: title,
        source: source,
        publishTime: publishTime,
        content: content || '无法提取正文内容',
        url: url,
        crawlTime: new Date().toISOString()
      }
    });
  } catch (error) {
    console.error('[DeepCrawl] 采集失败:', error.message);
    res.json({ code: 1, msg: `深度采集失败: ${error.message}` });
  }
});

/**
 * 保存采集数据到数据库
 * POST /api/crawler/save-collection
 * Body: { items: [...] }
 */
app.post('/api/crawler/save-collection', authMiddleware, async (req, res) => {
  try {
    const { items } = req.body;
    
    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.json({ code: 1, msg: '没有要保存的数据' });
    }

    // 创建采集数据表（如果不存在）
    db.run(`
      CREATE TABLE IF NOT EXISTS collected_data (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        summary TEXT,
        content TEXT,
        cover TEXT,
        url TEXT UNIQUE,
        source TEXT,
        publish_time TEXT,
        deep_crawled INTEGER DEFAULT 0,
        deep_content TEXT,
        keyword TEXT,
        sentiment TEXT,
        status TEXT DEFAULT 'pending',
        created_by TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);
    saveDatabase();

    const now = new Date().toISOString();
    let savedCount = 0;
    const savedIds = [];

    for (const item of items) {
      // 检查URL是否已存在
      const existing = getOne('SELECT id FROM collected_data WHERE url = ?', [item.url]);
      if (existing) {
        continue; // 跳过已存在的数据
      }

      const id = uuidv4();
      
      // 简单情感分析
      let sentiment = 'neutral';
      const text = ((item.title || '') + ' ' + (item.summary || '')).toLowerCase();
      const positiveWords = ['成功', '突破', '增长', '提升', '优秀', '领先', '创新', '进步', '发展', '好评', '利好'];
      const negativeWords = ['问题', '困难', '下降', '风险', '危机', '负面', '投诉', '质疑', '争议', '失败', '损失'];
      
      let positiveCount = 0;
      let negativeCount = 0;
      positiveWords.forEach(word => { if (text.includes(word)) positiveCount++; });
      negativeWords.forEach(word => { if (text.includes(word)) negativeCount++; });
      
      if (positiveCount > negativeCount) sentiment = 'positive';
      else if (negativeCount > positiveCount) sentiment = 'negative';

      runQuery(`
        INSERT INTO collected_data (id, title, summary, content, cover, url, source, publish_time, deep_crawled, deep_content, sentiment, created_by, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        id,
        item.title || '',
        item.summary || '',
        item.deepContent?.content || '',
        item.cover || '',
        item.url || '',
        item.source || '',
        item.publishTime || '',
        item.deepCrawled ? 1 : 0,
        item.deepContent ? JSON.stringify(item.deepContent) : null,
        sentiment,
        req.session.user.id,
        now,
        now
      ]);
      
      savedCount++;
      savedIds.push(item.id);
    }

    console.log('[SaveCollection] 保存成功:', savedCount, '条');

    res.json({
      code: 0,
      msg: `成功保存 ${savedCount} 条数据`,
      data: { saved: savedCount, savedIds: savedIds }
    });
  } catch (error) {
    console.error('[SaveCollection] 保存失败:', error.message);
    res.json({ code: 1, msg: `保存失败: ${error.message}` });
  }
});

/**
 * 获取采集数据统计
 * GET /api/collected-data/stats
 */
app.get('/api/collected-data/stats', authMiddleware, async (req, res) => {
  try {
    const total = getOne('SELECT COUNT(*) as count FROM collected_data');
    const deepCrawled = getOne('SELECT COUNT(*) as count FROM collected_data WHERE deep_crawled = 1');
    const imported = getOne('SELECT COUNT(*) as count FROM collected_data WHERE is_imported = 1');
    const today = getOne("SELECT COUNT(*) as count FROM collected_data WHERE date(created_at) = date('now')");
    
    res.json({
      code: 0,
      data: {
        total: total ? total.count : 0,
        deepCrawled: deepCrawled ? deepCrawled.count : 0,
        imported: imported ? imported.count : 0,
        today: today ? today.count : 0
      }
    });
  } catch (error) {
    res.json({ code: 1, msg: error.message });
  }
});

/**
 * 获取已保存的采集数据
 * GET /api/collected-data?page=1&limit=20&keyword=&sentiment=
 */
app.get('/api/collected-data', authMiddleware, async (req, res) => {
  try {
    const { page = 1, limit = 20, keyword, sentiment, status, deep_crawled, is_imported } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);

    let sql = 'SELECT * FROM collected_data WHERE 1=1';
    let countSql = 'SELECT COUNT(*) as total FROM collected_data WHERE 1=1';
    const params = [];

    if (keyword) {
      sql += ' AND (title LIKE ? OR summary LIKE ? OR keyword LIKE ?)';
      countSql += ' AND (title LIKE ? OR summary LIKE ? OR keyword LIKE ?)';
      params.push(`%${keyword}%`, `%${keyword}%`, `%${keyword}%`);
    }

    if (sentiment) {
      sql += ' AND sentiment = ?';
      countSql += ' AND sentiment = ?';
      params.push(sentiment);
    }

    if (status) {
      sql += ' AND status = ?';
      countSql += ' AND status = ?';
      params.push(status);
    }

    if (deep_crawled !== undefined && deep_crawled !== '') {
      sql += ' AND deep_crawled = ?';
      countSql += ' AND deep_crawled = ?';
      params.push(parseInt(deep_crawled));
    }

    if (is_imported !== undefined && is_imported !== '') {
      sql += ' AND is_imported = ?';
      countSql += ' AND is_imported = ?';
      params.push(parseInt(is_imported));
    }

    const totalResult = getOne(countSql, params);
    const total = totalResult ? totalResult.total : 0;

    sql += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
    const records = getAll(sql, [...params, parseInt(limit), offset]);

    res.json({
      code: 0,
      data: records,
      count: total,
      page: parseInt(page),
      limit: parseInt(limit)
    });
  } catch (error) {
    console.error('[CollectedData] 获取失败:', error.message);
    res.json({ code: 1, msg: `获取失败: ${error.message}` });
  }
});

/**
 * 更新采集数据的深度采集内容
 * PUT /api/collected-data/:id/deep-content
 */
app.put('/api/collected-data/:id/deep-content', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const { deep_content } = req.body;
    
    const record = getOne('SELECT * FROM collected_data WHERE id = ?', [id]);
    if (!record) {
      return res.json({ code: 1, msg: '数据不存在' });
    }

    const now = new Date().toISOString();
    runQuery('UPDATE collected_data SET deep_crawled = 1, deep_content = ?, content = ?, updated_at = ? WHERE id = ?',
      [JSON.stringify(deep_content), deep_content.content || '', now, id]);
    
    res.json({ code: 0, msg: '更新成功' });
  } catch (error) {
    console.error('[CollectedData] 更新深度内容失败:', error.message);
    res.json({ code: 1, msg: `更新失败: ${error.message}` });
  }
});

/**
 * 删除采集数据
 * DELETE /api/collected-data/:id
 */
app.delete('/api/collected-data/:id', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    
    const record = getOne('SELECT * FROM collected_data WHERE id = ?', [id]);
    if (!record) {
      return res.json({ code: 1, msg: '数据不存在' });
    }

    runQuery('DELETE FROM collected_data WHERE id = ?', [id]);
    res.json({ code: 0, msg: '删除成功' });
  } catch (error) {
    console.error('[CollectedData] 删除失败:', error.message);
    res.json({ code: 1, msg: `删除失败: ${error.message}` });
  }
});

/**
 * 批量删除采集数据
 * POST /api/collected-data/batch-delete
 * Body: { ids: [...] }
 */
app.post('/api/collected-data/batch-delete', authMiddleware, async (req, res) => {
  try {
    const { ids } = req.body;
    
    if (!ids || !Array.isArray(ids) || ids.length === 0) {
      return res.json({ code: 1, msg: '请选择要删除的数据' });
    }

    const placeholders = ids.map(() => '?').join(',');
    runQuery(`DELETE FROM collected_data WHERE id IN (${placeholders})`, ids);
    
    res.json({ code: 0, msg: `成功删除 ${ids.length} 条数据` });
  } catch (error) {
    console.error('[CollectedData] 批量删除失败:', error.message);
    res.json({ code: 1, msg: `删除失败: ${error.message}` });
  }
});

// ==================== AI 报告生成 API ====================

/**
 * AI生成舆情报告
 * POST /api/ai/generate-report
 * Body: { items: [...] }
 */
app.post('/api/ai/generate-report', authMiddleware, async (req, res) => {
  try {
    const { items } = req.body;
    
    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.json({ code: 1, msg: '请选择要分析的数据' });
    }

    console.log('[AI] 开始生成舆情报告，数据量:', items.length);

    // 分析数据
    const titles = items.map(item => item.title).join('\n');
    const summaries = items.map(item => item.summary || '').filter(s => s).join('\n');
    const sources = [...new Set(items.map(item => item.source))];
    const keywords = [...new Set(items.map(item => item.keyword).filter(k => k))];
    
    // 情感分析
    const positiveWords = ['成功', '突破', '增长', '提升', '优秀', '领先', '创新', '进步', '发展', '好评', '利好', '上涨', '盈利', '合作', '支持'];
    const negativeWords = ['问题', '困难', '下降', '风险', '危机', '负面', '投诉', '质疑', '争议', '失败', '损失', '下跌', '亏损', '违规', '处罚'];
    
    let positiveCount = 0;
    let negativeCount = 0;
    let neutralCount = 0;
    
    items.forEach(item => {
      const text = ((item.title || '') + ' ' + (item.summary || '')).toLowerCase();
      let pCount = 0, nCount = 0;
      
      positiveWords.forEach(word => { if (text.includes(word)) pCount++; });
      negativeWords.forEach(word => { if (text.includes(word)) nCount++; });
      
      if (pCount > nCount) positiveCount++;
      else if (nCount > pCount) negativeCount++;
      else neutralCount++;
    });
    
    const total = items.length;
    const sentiment = {
      positive: Math.round((positiveCount / total) * 100),
      neutral: Math.round((neutralCount / total) * 100),
      negative: Math.round((negativeCount / total) * 100)
    };
    
    // 确保总和为100
    const diff = 100 - sentiment.positive - sentiment.neutral - sentiment.negative;
    sentiment.neutral += diff;

    // 提取热点话题（从标题中提取高频词）
    const wordFreq = {};
    items.forEach(item => {
      const words = (item.title || '').replace(/[^\u4e00-\u9fa5a-zA-Z0-9]/g, ' ').split(/\s+/).filter(w => w.length >= 2);
      words.forEach(word => {
        wordFreq[word] = (wordFreq[word] || 0) + 1;
      });
    });
    
    const hotTopics = Object.entries(wordFreq)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 8)
      .map(([word]) => word);

    // 生成报告内容
    const keywordStr = keywords.length > 0 ? keywords.join('、') : '综合舆情';
    const now = new Date();
    const dateStr = now.toLocaleDateString('zh-CN', { year: 'numeric', month: 'long', day: 'numeric' });
    
    const report = {
      title: `${keywordStr}舆情分析报告（${dateStr}）`,
      createTime: now.toLocaleString('zh-CN'),
      summary: `本报告基于${items.length}条来自${sources.slice(0, 5).join('、')}等渠道的舆情数据进行分析。整体舆情态势${sentiment.positive > sentiment.negative ? '偏向正面' : sentiment.negative > sentiment.positive ? '存在一定负面倾向' : '保持中性'}，正面信息占比${sentiment.positive}%，中性信息占比${sentiment.neutral}%，负面信息占比${sentiment.negative}%。主要涉及${hotTopics.slice(0, 5).join('、')}等话题领域。`,
      analysis: `通过对采集数据的深度分析，发现当前舆情呈现以下特点：\n\n1. 信息来源多元化：数据来源涵盖${sources.join('、')}等${sources.length}个渠道，信息覆盖面较广。\n\n2. 话题集中度：舆情主要围绕${hotTopics.slice(0, 3).join('、')}等核心话题展开，反映出公众对相关领域的高度关注。\n\n3. 情感倾向分析：${sentiment.positive > 50 ? '正面舆情占据主导地位，整体舆论环境较为积极' : sentiment.negative > 30 ? '存在一定比例的负面舆情，需要关注潜在风险点' : '舆情整体保持中性，各方观点较为均衡'}。\n\n4. 传播特征：从数据时间分布来看，相关话题持续受到关注，舆情热度${items.length > 20 ? '较高' : '适中'}。`,
      sentiment: sentiment,
      hotTopics: hotTopics,
      suggestions: `基于以上分析，提出以下建议：\n\n1. ${sentiment.positive > 50 ? '继续保持良好的舆论态势，积极传播正面信息，巩固品牌形象。' : '加强正面信息的传播力度，提升公众认知度和好感度。'}\n\n2. ${sentiment.negative > 20 ? '密切关注负面舆情动态，及时回应公众关切，做好舆情引导工作。' : '持续监测舆情变化，建立预警机制，防范潜在风险。'}\n\n3. 针对${hotTopics.slice(0, 2).join('、')}等热点话题，建议制定专项传播策略，把握舆论主动权。\n\n4. 建立常态化舆情监测机制，定期进行舆情分析，为决策提供数据支撑。`
    };

    console.log('[AI] 报告生成成功:', report.title);

    res.json({
      code: 0,
      msg: '报告生成成功',
      data: report
    });
  } catch (error) {
    console.error('[AI] 报告生成失败:', error.message);
    res.json({ code: 1, msg: `报告生成失败: ${error.message}` });
  }
});

// ==================== 舆情搜索 API ====================

/**
 * 舆情搜索
 * GET /api/sentiment/search?keyword=关键字
 * 搜索报告和抓取记录中的舆情信息
 */
app.get('/api/sentiment/search', authMiddleware, async (req, res) => {
  try {
    const { keyword } = req.query;
    
    if (!keyword || !keyword.trim()) {
      return res.json({ code: 1, msg: '请输入搜索关键词' });
    }

    const searchTerm = `%${keyword.trim()}%`;
    const results = [];

    // 搜索报告
    const reports = getAll(`
      SELECT id, title, summary, content, status, created_at 
      FROM reports 
      WHERE (title LIKE ? OR summary LIKE ? OR content LIKE ?)
      ORDER BY created_at DESC
      LIMIT 50
    `, [searchTerm, searchTerm, searchTerm]);

    reports.forEach(report => {
      // 简单的情感分析（基于关键词）
      let sentiment = 'neutral';
      const text = (report.title + ' ' + (report.summary || '') + ' ' + (report.content || '')).toLowerCase();
      
      const positiveWords = ['成功', '突破', '增长', '提升', '优秀', '领先', '创新', '进步', '发展', '好评'];
      const negativeWords = ['问题', '困难', '下降', '风险', '危机', '负面', '投诉', '质疑', '争议', '失败'];
      
      let positiveCount = 0;
      let negativeCount = 0;
      
      positiveWords.forEach(word => {
        if (text.includes(word)) positiveCount++;
      });
      negativeWords.forEach(word => {
        if (text.includes(word)) negativeCount++;
      });
      
      if (positiveCount > negativeCount) sentiment = 'positive';
      else if (negativeCount > positiveCount) sentiment = 'negative';

      results.push({
        id: report.id,
        title: report.title,
        summary: report.summary || (report.content ? report.content.substring(0, 200) : ''),
        content: report.content,
        sentiment: sentiment,
        source: '舆情报告',
        created_at: report.created_at,
        type: 'report'
      });
    });

    // 搜索抓取记录
    try {
      const crawlRecords = getAll(`
        SELECT id, keyword, title, summary, url, source, publish_time, crawl_time 
        FROM crawl_records 
        WHERE (title LIKE ? OR summary LIKE ? OR keyword LIKE ?)
        ORDER BY crawl_time DESC
        LIMIT 50
      `, [searchTerm, searchTerm, searchTerm]);

      crawlRecords.forEach(record => {
        // 简单的情感分析
        let sentiment = 'neutral';
        const text = (record.title + ' ' + (record.summary || '')).toLowerCase();
        
        const positiveWords = ['成功', '突破', '增长', '提升', '优秀', '领先', '创新', '进步', '发展', '好评'];
        const negativeWords = ['问题', '困难', '下降', '风险', '危机', '负面', '投诉', '质疑', '争议', '失败'];
        
        let positiveCount = 0;
        let negativeCount = 0;
        
        positiveWords.forEach(word => {
          if (text.includes(word)) positiveCount++;
        });
        negativeWords.forEach(word => {
          if (text.includes(word)) negativeCount++;
        });
        
        if (positiveCount > negativeCount) sentiment = 'positive';
        else if (negativeCount > positiveCount) sentiment = 'negative';

        results.push({
          id: record.id,
          title: record.title,
          summary: record.summary,
          content: record.summary,
          sentiment: sentiment,
          source: record.source || '网络采集',
          url: record.url,
          created_at: record.publish_time || record.crawl_time,
          type: 'crawl'
        });
      });
    } catch (e) {
      // 抓取记录表可能不存在，忽略错误
    }

    // 按时间排序
    results.sort((a, b) => {
      const dateA = new Date(a.created_at || 0);
      const dateB = new Date(b.created_at || 0);
      return dateB - dateA;
    });

    // 限制返回数量
    const limitedResults = results.slice(0, 50);

    res.json({
      code: 0,
      data: limitedResults,
      count: limitedResults.length
    });
  } catch (error) {
    console.error('[Sentiment Search] 搜索失败:', error.message);
    res.json({ code: 1, msg: `搜索失败: ${error.message}` });
  }
});

// ==================== 资源管理 API ====================

// 获取资源分类列表
app.get('/api/resource-categories', authMiddleware, (req, res) => {
  try {
    const categories = getAll('SELECT * FROM resource_categories WHERE status = 1 ORDER BY sort_order ASC');
    res.json({ code: 0, data: categories });
  } catch (error) {
    res.json({ code: 1, msg: error.message });
  }
});

// 添加资源分类
app.post('/api/resource-categories', authMiddleware, adminMiddleware, (req, res) => {
  try {
    const { name, code, parent_id, icon, description, sort_order } = req.body;
    if (!name || !code) {
      return res.json({ code: 1, msg: '分类名称和编码不能为空' });
    }
    const existing = getOne('SELECT id FROM resource_categories WHERE code = ?', [code]);
    if (existing) {
      return res.json({ code: 1, msg: '分类编码已存在' });
    }
    const id = uuidv4();
    const now = new Date().toISOString();
    runQuery('INSERT INTO resource_categories (id, name, code, parent_id, icon, description, sort_order, created_by, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [id, name, code, parent_id || null, icon || '', description || '', sort_order || 0, req.session.user.id, now, now]);
    res.json({ code: 0, msg: '添加成功', data: { id } });
  } catch (error) {
    res.json({ code: 1, msg: error.message });
  }
});

// 获取资源标签列表
app.get('/api/resource-tags', authMiddleware, (req, res) => {
  try {
    const tags = getAll('SELECT * FROM resource_tags ORDER BY use_count DESC');
    res.json({ code: 0, data: tags });
  } catch (error) {
    res.json({ code: 1, msg: error.message });
  }
});

// 获取资源列表
app.get('/api/resources', authMiddleware, (req, res) => {
  try {
    const { page = 1, limit = 20, category_id, type, sentiment, status, keyword } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);

    let sql = 'SELECT r.*, c.name as category_name FROM resources r LEFT JOIN resource_categories c ON r.category_id = c.id WHERE 1=1';
    let countSql = 'SELECT COUNT(*) as total FROM resources WHERE 1=1';
    const params = [];

    if (category_id) {
      sql += ' AND r.category_id = ?';
      countSql += ' AND category_id = ?';
      params.push(category_id);
    }
    if (type) {
      sql += ' AND r.type = ?';
      countSql += ' AND type = ?';
      params.push(type);
    }
    if (sentiment) {
      sql += ' AND r.sentiment = ?';
      countSql += ' AND sentiment = ?';
      params.push(sentiment);
    }
    if (status) {
      sql += ' AND r.status = ?';
      countSql += ' AND status = ?';
      params.push(status);
    }
    if (keyword) {
      sql += ' AND (r.title LIKE ? OR r.summary LIKE ?)';
      countSql += ' AND (title LIKE ? OR summary LIKE ?)';
      params.push(`%${keyword}%`, `%${keyword}%`);
    }

    const totalResult = getOne(countSql, params);
    const total = totalResult ? totalResult.total : 0;

    sql += ' ORDER BY r.created_at DESC LIMIT ? OFFSET ?';
    const resources = getAll(sql, [...params, parseInt(limit), offset]);

    res.json({ code: 0, data: resources, count: total, page: parseInt(page), limit: parseInt(limit) });
  } catch (error) {
    res.json({ code: 1, msg: error.message });
  }
});

// 获取资源详情
app.get('/api/resources/:id', authMiddleware, (req, res) => {
  try {
    const { id } = req.params;
    const resource = getOne('SELECT r.*, c.name as category_name FROM resources r LEFT JOIN resource_categories c ON r.category_id = c.id WHERE r.id = ?', [id]);
    if (!resource) {
      return res.json({ code: 1, msg: '资源不存在' });
    }
    // 增加浏览次数
    runQuery('UPDATE resources SET view_count = view_count + 1 WHERE id = ?', [id]);
    res.json({ code: 0, data: resource });
  } catch (error) {
    res.json({ code: 1, msg: error.message });
  }
});

// 添加资源
app.post('/api/resources', authMiddleware, (req, res) => {
  try {
    const { title, category_id, type, source, source_url, cover, summary, content, tags, sentiment, importance, status, publish_time } = req.body;
    if (!title) {
      return res.json({ code: 1, msg: '资源标题不能为空' });
    }
    const id = uuidv4();
    const now = new Date().toISOString();
    runQuery(`INSERT INTO resources (id, title, category_id, type, source, source_url, cover, summary, content, tags, sentiment, importance, status, publish_time, created_by, created_at, updated_at) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [id, title, category_id || null, type || 'article', source || '', source_url || '', cover || '', summary || '', content || '', 
       tags ? JSON.stringify(tags) : null, sentiment || 'neutral', importance || 0, status || 'pending', publish_time || now, req.session.user.id, now, now]);
    
    // 记录操作日志
    runQuery('INSERT INTO resource_logs (id, resource_id, action, details, operator_id, operator_name, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [uuidv4(), id, 'create', '创建资源', req.session.user.id, req.session.user.username, now]);
    
    res.json({ code: 0, msg: '添加成功', data: { id } });
  } catch (error) {
    res.json({ code: 1, msg: error.message });
  }
});

// 更新资源
app.put('/api/resources/:id', authMiddleware, (req, res) => {
  try {
    const { id } = req.params;
    const { title, category_id, type, source, source_url, cover, summary, content, tags, sentiment, importance, status } = req.body;
    
    const resource = getOne('SELECT * FROM resources WHERE id = ?', [id]);
    if (!resource) {
      return res.json({ code: 1, msg: '资源不存在' });
    }
    
    const now = new Date().toISOString();
    runQuery(`UPDATE resources SET title = ?, category_id = ?, type = ?, source = ?, source_url = ?, cover = ?, summary = ?, content = ?, tags = ?, sentiment = ?, importance = ?, status = ?, updated_at = ? WHERE id = ?`,
      [title || resource.title, category_id, type || resource.type, source, source_url, cover, summary, content, 
       tags ? JSON.stringify(tags) : resource.tags, sentiment || resource.sentiment, importance ?? resource.importance, status || resource.status, now, id]);
    
    // 记录操作日志
    runQuery('INSERT INTO resource_logs (id, resource_id, action, details, operator_id, operator_name, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [uuidv4(), id, 'update', '更新资源', req.session.user.id, req.session.user.username, now]);
    
    res.json({ code: 0, msg: '更新成功' });
  } catch (error) {
    res.json({ code: 1, msg: error.message });
  }
});

// 删除资源
app.delete('/api/resources/:id', authMiddleware, (req, res) => {
  try {
    const { id } = req.params;
    const resource = getOne('SELECT * FROM resources WHERE id = ?', [id]);
    if (!resource) {
      return res.json({ code: 1, msg: '资源不存在' });
    }
    runQuery('DELETE FROM resources WHERE id = ?', [id]);
    res.json({ code: 0, msg: '删除成功' });
  } catch (error) {
    res.json({ code: 1, msg: error.message });
  }
});

// 批量删除资源
app.post('/api/resources/batch-delete', authMiddleware, (req, res) => {
  try {
    const { ids } = req.body;
    if (!ids || !Array.isArray(ids) || ids.length === 0) {
      return res.json({ code: 1, msg: '请选择要删除的资源' });
    }
    const placeholders = ids.map(() => '?').join(',');
    runQuery(`DELETE FROM resources WHERE id IN (${placeholders})`, ids);
    res.json({ code: 0, msg: `成功删除 ${ids.length} 条资源` });
  } catch (error) {
    res.json({ code: 1, msg: error.message });
  }
});

// 从采集数据导入到资源库
app.post('/api/resources/import-from-collected', authMiddleware, (req, res) => {
  try {
    const { ids, category_id } = req.body;
    if (!ids || !Array.isArray(ids) || ids.length === 0) {
      return res.json({ code: 1, msg: '请选择要导入的数据' });
    }

    const now = new Date().toISOString();
    let importedCount = 0;

    ids.forEach(collectedId => {
      const collected = getOne('SELECT * FROM collected_data WHERE id = ?', [collectedId]);
      if (collected && !collected.is_imported) {
        const resourceId = uuidv4();
        runQuery(`INSERT INTO resources (id, title, category_id, type, source, source_url, cover, summary, content, sentiment, status, publish_time, created_by, created_at, updated_at) 
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [resourceId, collected.title, category_id || null, 'article', collected.source, collected.url, collected.cover, 
           collected.summary, collected.content || '', collected.sentiment, 'pending', collected.publish_time, req.session.user.id, now, now]);
        
        // 标记为已导入
        runQuery('UPDATE collected_data SET is_imported = 1, resource_id = ?, updated_at = ? WHERE id = ?', [resourceId, now, collectedId]);
        importedCount++;
      }
    });

    res.json({ code: 0, msg: `成功导入 ${importedCount} 条资源`, data: { imported: importedCount } });
  } catch (error) {
    res.json({ code: 1, msg: error.message });
  }
});

// 获取资源统计
app.get('/api/resources/stats/overview', authMiddleware, (req, res) => {
  try {
    const total = getOne('SELECT COUNT(*) as count FROM resources');
    const byCategory = getAll('SELECT c.name, COUNT(r.id) as count FROM resource_categories c LEFT JOIN resources r ON c.id = r.category_id GROUP BY c.id ORDER BY count DESC');
    const bySentiment = getAll('SELECT sentiment, COUNT(*) as count FROM resources GROUP BY sentiment');
    const byStatus = getAll('SELECT status, COUNT(*) as count FROM resources GROUP BY status');
    const recentCount = getOne('SELECT COUNT(*) as count FROM resources WHERE created_at >= datetime("now", "-7 days")');

    res.json({
      code: 0,
      data: {
        total: total ? total.count : 0,
        recentCount: recentCount ? recentCount.count : 0,
        byCategory,
        bySentiment,
        byStatus
      }
    });
  } catch (error) {
    res.json({ code: 1, msg: error.message });
  }
});

// 页面路由
app.get('/', (req, res) => {
  res.redirect('/login.html');
});

app.get('/login', (req, res) => {
  res.redirect('/login.html');
});

// 启动服务器
initDatabase().then(() => {
  app.listen(PORT, () => {
    console.log(`服务器运行在 http://localhost:${PORT}`);
    console.log('默认管理员账户: admin / admin123');
  });
}).catch(err => {
  console.error('数据库初始化失败:', err);
  process.exit(1);
});
