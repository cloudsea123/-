/**
 * 新闻数据抓取模块
 * 支持多个新闻源的数据采集
 */

const axios = require('axios');
const cheerio = require('cheerio');
const iconv = require('iconv-lite');

// 请求头配置
const DEFAULT_HEADERS = {
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
};

/**
 * 新闻爬虫类
 */
class BaiduNewsCrawler {
  constructor(options = {}) {
    this.headers = { ...DEFAULT_HEADERS, ...options.headers };
    this.timeout = options.timeout || 15000;
  }

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * 从360新闻搜索获取数据
   */
  async fetch360News(keyword, page = 1) {
    const url = `https://news.so.com/ns?q=${encodeURIComponent(keyword)}&pn=${page}&rank=time`;
    
    const response = await axios.get(url, {
      headers: this.headers,
      timeout: this.timeout
    });
    
    const $ = cheerio.load(response.data);
    const items = [];
    
    $('li.res-list').each((i, el) => {
      const $item = $(el);
      const $link = $item.find('a').first();
      const title = $item.find('h3').text().trim() || $link.attr('title') || '';
      const link = $link.attr('href');
      const summary = $item.find('.g-linkinfo').text().trim();
      const source = $item.find('.g-source-name').text().trim();
      const time = $item.find('.g-source-time').text().trim();
      const cover = $item.find('img').first().attr('src') || '';
      
      if (title && title.length > 5) {
        items.push({
          title: title.replace(/<[^>]+>/g, '').trim(),
          url: link && link.startsWith('http') ? link : '',
          summary: summary || '暂无摘要',
          source: source || '360新闻',
          publishTime: time,
          cover: cover.startsWith('http') ? cover : '',
          crawlTime: new Date().toISOString()
        });
      }
    });
    
    return items;
  }

  /**
   * 搜索新闻 - 使用360新闻
   */
  async search(keyword, options = {}) {
    const { page = 1 } = options;
    
    if (!keyword || typeof keyword !== 'string') {
      throw new Error('关键字不能为空');
    }

    console.log(`[Crawler] 正在搜索: ${keyword}, 页码: ${page}`);
    
    const items = await this.fetch360News(keyword, page);
    console.log(`[Crawler] 获取 ${items.length} 条结果`);

    return {
      keyword,
      page,
      total: items.length,
      items: items,
      crawlTime: new Date().toISOString()
    };
  }

  async batchSearch(keywords, options = {}) {
    const { delay = 2000 } = options;
    const results = [];

    for (const keyword of keywords) {
      try {
        const result = await this.search(keyword, options);
        results.push(result);
        if (keywords.indexOf(keyword) < keywords.length - 1) {
          await this.sleep(delay);
        }
      } catch (error) {
        results.push({ keyword, error: error.message, items: [] });
      }
    }

    return results;
  }

  async searchMultiplePages(keyword, pages = 3) {
    const allItems = [];
    
    for (let page = 1; page <= pages; page++) {
      try {
        const result = await this.search(keyword, { page });
        allItems.push(...result.items);
        if (page < pages) await this.sleep(1000);
      } catch (error) {
        console.error(`[Crawler] 第${page}页失败:`, error.message);
      }
    }

    // 去重
    const seen = new Set();
    const uniqueItems = allItems.filter(item => {
      if (seen.has(item.title)) return false;
      seen.add(item.title);
      return true;
    });

    return {
      keyword,
      total: uniqueItems.length,
      items: uniqueItems,
      crawlTime: new Date().toISOString()
    };
  }
}

const crawler = new BaiduNewsCrawler();

module.exports = {
  BaiduNewsCrawler,
  crawler,
  search: (keyword, options) => crawler.search(keyword, options),
  batchSearch: (keywords, options) => crawler.batchSearch(keywords, options),
  searchMultiplePages: (keyword, pages) => crawler.searchMultiplePages(keyword, pages)
};
