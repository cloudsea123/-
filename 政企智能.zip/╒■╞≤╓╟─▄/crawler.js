/**
 * 百度新闻数据抓取模块
 * 用于从百度新闻搜索接口获取舆情数据
 */

const axios = require('axios');
const cheerio = require('cheerio');
const iconv = require('iconv-lite');

// 请求头配置（模拟浏览器）
const DEFAULT_HEADERS = {
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
  'Accept-Encoding': 'gzip, deflate, br',
  'Accept-Language': 'zh-CN,zh;q=0.9',
  'Cache-Control': 'no-cache',
  'Connection': 'keep-alive',
  'Host': 'www.baidu.com',
  'Pragma': 'no-cache',
  'Sec-Ch-Ua': '"Not)A;Brand";v="24", "Chromium";v="116"',
  'Sec-Ch-Ua-Mobile': '?0',
  'Sec-Ch-Ua-Platform': '"Windows"',
  'Sec-Fetch-Dest': 'document',
  'Sec-Fetch-Mode': 'navigate',
  'Sec-Fetch-Site': 'none',
  'Sec-Fetch-User': '?1',
  'Upgrade-Insecure-Requests': '1',
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.5845.97 Safari/537.36 Core/1.116.586.400 QQBrowser/19.8.6883.400'
};

// Cookie配置（可选，用于提高请求成功率）
const DEFAULT_COOKIE = 'BIDUPSID=D48AC21A701043225723F7B0416A45A5; PSTM=1749868400; BD_UPN=1a314753; BAIDUID=D48AC21A70104322974B66FAE2F73383:SL=0:NR=10:FG=1';

/**
 * 百度新闻爬虫类
 */
class BaiduNewsCrawler {
  constructor(options = {}) {
    this.baseUrl = 'https://www.baidu.com/s';
    this.headers = { ...DEFAULT_HEADERS, ...options.headers };
    this.cookie = options.cookie || DEFAULT_COOKIE;
    this.timeout = options.timeout || 15000;
    this.retryCount = options.retryCount || 3;
    this.retryDelay = options.retryDelay || 1000;
  }

  /**
   * 延迟函数
   * @param {number} ms 毫秒数
   */
  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * 构建请求URL
   * @param {string} keyword 搜索关键字
   * @param {number} page 页码（从0开始）
   */
  buildUrl(keyword, page = 0) {
    const params = new URLSearchParams({
      rtt: '1',
      bsst: '1',
      cl: '2',
      tn: 'news',
      rsv_dl: 'ns_pc',
      word: keyword,
      pn: (page * 10).toString() // 百度新闻每页10条，pn为偏移量
    });
    return `${this.baseUrl}?${params.toString()}`;
  }

  /**
   * 发送HTTP请求
   * @param {string} url 请求URL
   */
  async fetchPage(url) {
    let lastError = null;
    
    for (let i = 0; i < this.retryCount; i++) {
      try {
        const response = await axios.get(url, {
          headers: {
            ...this.headers,
            'Cookie': this.cookie
          },
          timeout: this.timeout,
          responseType: 'arraybuffer', // 获取原始字节数据
          maxRedirects: 5,
          validateStatus: (status) => status >= 200 && status < 400
        });

        // 处理编码（百度可能返回GBK或UTF-8）
        let html;
        const contentType = response.headers['content-type'] || '';
        if (contentType.includes('gbk') || contentType.includes('gb2312')) {
          html = iconv.decode(Buffer.from(response.data), 'gbk');
        } else {
          html = iconv.decode(Buffer.from(response.data), 'utf-8');
        }

        return html;
      } catch (error) {
        lastError = error;
        console.error(`请求失败 (尝试 ${i + 1}/${this.retryCount}):`, error.message);
        if (i < this.retryCount - 1) {
          await this.sleep(this.retryDelay * (i + 1));
        }
      }
    }
    
    throw new Error(`请求失败，已重试${this.retryCount}次: ${lastError?.message}`);
  }

  /**
   * 解析HTML提取新闻数据
   * @param {string} html HTML内容
   */
  parseNewsData(html) {
    const $ = cheerio.load(html);
    const newsItems = [];

    // 百度新闻搜索结果的选择器
    // 主要结果容器
    $('.result-op, .result, .c-container').each((index, element) => {
      try {
        const $item = $(element);
        
        // 提取标题和链接
        let title = '';
        let url = '';
        
        // 尝试多种选择器获取标题
        const titleSelectors = [
          'h3 a',
          '.c-title a',
          '.news-title a',
          'a[href*="baidu.com/link"]'
        ];
        
        for (const selector of titleSelectors) {
          const $title = $item.find(selector).first();
          if ($title.length) {
            title = $title.text().trim();
            url = $title.attr('href') || '';
            break;
          }
        }

        if (!title) return; // 跳过没有标题的项

        // 提取概要/摘要
        let summary = '';
        const summarySelectors = [
          '.c-summary',
          '.c-abstract',
          '.news-summary',
          '.c-span-last',
          '.content-right_8Zs40'
        ];
        
        for (const selector of summarySelectors) {
          const $summary = $item.find(selector).first();
          if ($summary.length) {
            summary = $summary.text().trim();
            break;
          }
        }
        
        // 如果没找到摘要，尝试获取整个内容区域的文本
        if (!summary) {
          summary = $item.find('.c-row, .c-span9').first().text().trim();
        }

        // 清理摘要文本
        summary = summary
          .replace(/\s+/g, ' ')
          .replace(/查看更多相关新闻>>/g, '')
          .trim();

        // 提取封面图片
        let cover = '';
        const $img = $item.find('img').first();
        if ($img.length) {
          cover = $img.attr('src') || $img.attr('data-src') || '';
          // 处理相对路径
          if (cover && !cover.startsWith('http')) {
            cover = cover.startsWith('//') ? `https:${cover}` : `https://www.baidu.com${cover}`;
          }
        }

        // 提取来源和时间
        let source = '';
        let publishTime = '';
        
        const sourceSelectors = [
          '.c-author',
          '.news-source',
          '.c-color-gray',
          '.c-color-gray2',
          '.source_1V3pw'
        ];
        
        for (const selector of sourceSelectors) {
          const $source = $item.find(selector).first();
          if ($source.length) {
            const sourceText = $source.text().trim();
            // 解析来源和时间（格式通常为：来源名称  时间）
            const parts = sourceText.split(/\s{2,}|\s+/);
            if (parts.length >= 1) {
              source = parts[0].trim();
            }
            if (parts.length >= 2) {
              publishTime = parts[parts.length - 1].trim();
            }
            break;
          }
        }

        // 只添加有效的新闻项
        if (title && title.length > 2) {
          newsItems.push({
            title: title,
            summary: summary || '暂无摘要',
            cover: cover || '',
            url: url,
            source: source || '未知来源',
            publishTime: publishTime || '',
            crawlTime: new Date().toISOString()
          });
        }
      } catch (e) {
        console.error('解析单条新闻失败:', e.message);
      }
    });

    return newsItems;
  }

  /**
   * 搜索新闻
   * @param {string} keyword 搜索关键字
   * @param {Object} options 选项
   * @param {number} options.page 页码（从1开始）
   * @param {number} options.pageSize 每页数量（百度固定为10）
   */
  async search(keyword, options = {}) {
    const { page = 1 } = options;
    
    if (!keyword || typeof keyword !== 'string') {
      throw new Error('关键字不能为空');
    }

    const url = this.buildUrl(keyword.trim(), page - 1);
    console.log(`正在抓取: ${keyword}, 页码: ${page}`);
    console.log(`请求URL: ${url}`);

    const html = await this.fetchPage(url);
    const newsItems = this.parseNewsData(html);

    return {
      keyword: keyword,
      page: page,
      total: newsItems.length,
      items: newsItems,
      crawlTime: new Date().toISOString()
    };
  }

  /**
   * 批量搜索多个关键字
   * @param {string[]} keywords 关键字数组
   * @param {Object} options 选项
   */
  async batchSearch(keywords, options = {}) {
    const { delay = 2000 } = options;
    const results = [];

    for (const keyword of keywords) {
      try {
        const result = await this.search(keyword, options);
        results.push(result);
        
        // 添加延迟避免请求过快
        if (keywords.indexOf(keyword) < keywords.length - 1) {
          await this.sleep(delay);
        }
      } catch (error) {
        console.error(`抓取关键字 "${keyword}" 失败:`, error.message);
        results.push({
          keyword: keyword,
          error: error.message,
          items: []
        });
      }
    }

    return results;
  }

  /**
   * 搜索多页数据
   * @param {string} keyword 关键字
   * @param {number} pages 页数
   */
  async searchMultiplePages(keyword, pages = 3) {
    const allItems = [];
    
    for (let page = 1; page <= pages; page++) {
      try {
        const result = await this.search(keyword, { page });
        allItems.push(...result.items);
        
        if (page < pages) {
          await this.sleep(2000); // 页面间延迟
        }
      } catch (error) {
        console.error(`抓取第${page}页失败:`, error.message);
      }
    }

    // 去重（根据标题）
    const uniqueItems = [];
    const seenTitles = new Set();
    
    for (const item of allItems) {
      if (!seenTitles.has(item.title)) {
        seenTitles.add(item.title);
        uniqueItems.push(item);
      }
    }

    return {
      keyword: keyword,
      total: uniqueItems.length,
      items: uniqueItems,
      crawlTime: new Date().toISOString()
    };
  }
}

// 创建默认实例
const crawler = new BaiduNewsCrawler();

// 导出模块
module.exports = {
  BaiduNewsCrawler,
  crawler,
  
  // 便捷方法
  search: (keyword, options) => crawler.search(keyword, options),
  batchSearch: (keywords, options) => crawler.batchSearch(keywords, options),
  searchMultiplePages: (keyword, pages) => crawler.searchMultiplePages(keyword, pages)
};
