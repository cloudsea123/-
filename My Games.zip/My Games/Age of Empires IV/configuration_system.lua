configuration =  
{
	[5] =  
	{
		setting = "mouseclamp",
		variantBool = true,
	},
	[9] =  
	{
		setting = "capturezonevisibility",
		variantUInt = 0,
	},
	[10] =  
	{
		setting = "dynamicresolutionallowedframetimevariance",
		variantFloat = 1.50000,
	},
	[11] =  
	{
		setting = "shadowfilter",
		variantUInt = 2,
	},
	[12] =  
	{
		setting = "remapcontrols",
		variantFloat = 1.00000,
	},
	[13] =  
	{
		setting = "hdrgamma",
		variantFloat = 0.50000,
	},
	[14] =  
	{
		setting = "selectionsilhouette",
		variantUInt = 2,
	},
	[15] =  
	{
		setting = "effectsdensity",
		variantUInt = 2,
	},
	[20] =  
	{
		setting = "variablerateshadingthreshold",
		variantFloat = 0.06000,
	},
	[22] =  
	{
		setting = "selectionboxopacity",
		variantFloat = 1.00000,
	},
	[29] =  
	{
		setting = "resolution",
		variantString = "2560:1600:0:0",
	},
	[30] =  
	{
		setting = "autodetect_previousgraphicsquality",
		variantUInt = 9999,
	},
	[31] =  
	{
		setting = "shadowsize",
		variantInt = -1,
	},
	[36] =  
	{
		setting = "texturedetail",
		variantUInt = 0,
	},
	[38] =  
	{
		setting = "fxforcespawnoffscreen",
		variantBool = false,
	},
	[42] =  
	{
		setting = "villagerquickfindbehaviour",
		variantInt = 0,
	},
	[43] =  
	{
		setting = "dynamicresolutionframesbeforeupsample",
		variantUInt = 25,
	},
	[45] =  
	{
		setting = "effectsfidelity",
		variantUInt = 2,
	},
	[46] =  
	{
		setting = "audioinputdevice",
		variantString = "",
	},
	[52] =  
	{
		setting = "audiooutputquality",
		variantUInt = 0,
	},
	[56] =  
	{
		setting = "texturestreamingminmipcount",
		variantUInt = 5,
	},
	[68] =  
	{
		setting = "distanceratewheelfactor",
		variantFloat = 1.00000,
	},
	[70] =  
	{
		setting = "villagerdoublepress",
		variantInt = 0,
	},
	[71] =  
	{
		setting = "adjustbrightness",
		variantFloat = 4.00000,
	},
	[76] =  
	{
		setting = "audiooutput",
		variantUInt = 1,
	},
	[81] =  
	{
		setting = "volumetriclighting",
		variantUInt = 2,
	},
	[83] =  
	{
		setting = "subtitlefont",
		variantUInt = 0,
	},
	[84] =  
	{
		setting = "physics",
		variantUInt = 2,
	},
	[88] =  
	{
		setting = "inputdevicetype",
		variantInt = 0,
	},
	[90] =  
	{
		setting = "antialiasing",
		variantFloat = 1.00000,
	},
	[94] =  
	{
		setting = "ambientocclusion",
		variantUInt = 3,
	},
	[95] =  
	{
		setting = "hdr",
		variantBool = false,
	},
	[102] =  
	{
		setting = "quickfindbehaviourpreset",
		variantInt = 0,
	},
	[110] =  
	{
		setting = "skeletalanimationlod",
		variantUInt = 1,
	},
	[111] =  
	{
		setting = "cursorscale",
		variantFloat = 1.00000,
	},
	[112] =  
	{
		setting = "controlsvisuals",
		variantFloat = 1.00000,
	},
	[113] =  
	{
		setting = "mousebuttonpanspeedfactor",
		variantFloat = 1.00000,
	},
	[114] =  
	{
		setting = "audiooutputdevice",
		variantString = "",
	},
	[116] =  
	{
		setting = "musicvolume",
		variantFloat = 1.00000,
	},
	[118] =  
	{
		setting = "farshadowmapsizeoverride",
		variantUInt = 0,
	},
	[119] =  
	{
		setting = "texturestreamingmaxmipcount",
		variantUInt = 10,
	},
	[120] =  
	{
		setting = "shadowmapsetdistanceoverride",
		variantUInt = 0,
	},
	[123] =  
	{
		setting = "animationquality",
		variantUInt = 2,
	},
	[127] =  
	{
		setting = "dynamicverticalsyncthreshold",
		variantFloat = 4.00000,
	},
	[131] =  
	{
		setting = "ingamechatuiscale",
		variantInt = 0,
	},
	[133] =  
	{
		setting = "dynamicresolutionframesbeforedownsample",
		variantUInt = 15,
	},
	[135] =  
	{
		setting = "shadowcascadeoverride",
		variantInt = -1,
	},
	[139] =  
	{
		setting = "nearshadowmapsizeoverride",
		variantUInt = 0,
	},
	[140] =  
	{
		setting = "windowmode",
		variantUInt = 0,
	},
	[141] =  
	{
		setting = "uiscale",
		variantFloat = 1.00000,
	},
	[145] =  
	{
		setting = "worldviewquality",
		variantUInt = 2,
	},
	[148] =  
	{
		setting = "terrainlod",
		variantInt = -1,
	},
	[149] =  
	{
		setting = "audiodynamicrange",
		variantUInt = 0,
	},
	[155] =  
	{
		setting = "gameplayscale",
		variantFloat = 1.00000,
	},
	[158] =  
	{
		setting = "dynamicresolutionadjustmentfactor",
		variantFloat = 1.00000,
	},
	[159] =  
	{
		setting = "arelabelsactive",
		variantBool = true,
	},
	[162] =  
	{
		setting = "usssortmethod",
		variantUInt = 0,
	},
	[164] =  
	{
		setting = "mousecursorspeed",
		variantFloat = 50.00000,
	},
	[165] =  
	{
		setting = "texturestreamingenabled",
		variantBool = false,
	},
	[167] =  
	{
		setting = "dynamicresolutionscalemin",
		variantFloat = 0.50000,
	},
	[169] =  
	{
		setting = "texturestreamingmaxmemoryusage",
		variantUInt = 128,
	},
	[175] =  
	{
		setting = "speechvolume",
		variantFloat = 1.00000,
	},
	[176] =  
	{
		setting = "subtitlevisibility",
		variantUInt = 2,
	},
	[178] =  
	{
		setting = "shadows",
		variantUInt = 4,
	},
	[182] =  
	{
		setting = "stronghighcontrast",
		variantBool = false,
	},
	[183] =  
	{
		setting = "hdrmaxbrightness",
		variantFloat = 10000.00000,
	},
	[185] =  
	{
		setting = "dynamiccamera",
		variantUInt = 0,
	},
	[187] =  
	{
		setting = "subtitlefontcolor",
		variantUInt = 0,
	},
	[190] =  
	{
		setting = "graphicsquality",
		variantUInt = 2,
	},
	[191] =  
	{
		setting = "verticalsync",
		variantBool = true,
	},
	[193] =  
	{
		setting = "resettraining",
		variantFloat = 3.00000,
	},
	[195] =  
	{
		setting = "reflections",
		variantUInt = 1,
	},
	[196] =  
	{
		setting = "waterreflectionsdisableoverride",
		variantBool = false,
	},
	[198] =  
	{
		setting = "moveactionspawningchance",
		variantFloat = 1.00000,
	},
	[201] =  
	{
		setting = "gen7",
		variantBool = false,
	},
	[202] =  
	{
		setting = "useonlysinglecascadingshadows",
		variantBool = false,
	},
	[205] =  
	{
		setting = "texturestreamingmaxconcurrentstreams",
		variantUInt = 32,
	},
	[206] =  
	{
		setting = "decoratorvisibility",
		variantUInt = 0,
	},
	[207] =  
	{
		setting = "frameratelimit",
		variantUInt = 0,
	},
	[211] =  
	{
		setting = "shadowmaptoggledistanceoverride",
		variantUInt = 0,
	},
	[212] =  
	{
		setting = "autoconfig_gameplayscaletargetresolution",
		variantString = "",
	},
	[216] =  
	{
		setting = "texturestreamingmaxcriticalcachedmemory",
		variantUInt = 32,
	},
	[218] =  
	{
		setting = "dynamicverticalsync",
		variantBool = false,
	},
	[219] =  
	{
		setting = "sfxvolume",
		variantFloat = 1.00000,
	},
	[220] =  
	{
		setting = "filterchat",
		variantBool = true,
	},
	[222] =  
	{
		setting = "texturestreamingcoveragebias",
		variantFloat = 2.00000,
	},
	[223] =  
	{
		setting = "captionscale",
		variantFloat = 1.00000,
	},
	[224] =  
	{
		setting = "militaryquickfindbehaviour",
		variantInt = 1,
	},
	[225] =  
	{
		setting = "modeldetail",
		variantUInt = 2,
	},
	[227] =  
	{
		setting = "movieplayerpixelcount",
		variantInt = 8294400,
	},
	[228] =  
	{
		setting = "mastervolume",
		variantFloat = 1.00000,
	},
	[229] =  
	{
		setting = "variablerateshading",
		variantBool = true,
	},
	[231] =  
	{
		setting = "controls",
		variantUInt = 0,
	},
	[236] =  
	{
		setting = "subtitleposition",
		variantUInt = 1,
	},
	[237] =  
	{
		setting = "ldrgamma",
		variantFloat = 0.50000,
	},
	[238] =  
	{
		setting = "audiobalance",
		variantFloat = 50.00000,
	},
	[239] =  
	{
		setting = "useonlylowshadowdrawstyle",
		variantBool = false,
	},
	[242] =  
	{
		setting = "terraindetail",
		variantUInt = 3,
	},
	[246] =  
	{
		setting = "dynamicresolutiondesiredframetime",
		variantFloat = 32.00000,
	},
	[250] =  
	{
		setting = "tauntsvolume",
		variantFloat = 1.00000,
	},
	[251] =  
	{
		setting = "screenshakeeffect",
		variantUInt = 0,
	},
}
migrations =  
{
	SetGen7ShadowsOff =  
	{
		extraInfo =  
		{
			wasGen7 =  
			{
				variantBool = false,
			},
		},
		time = 1735465233,
	},
}
version = 3666938

