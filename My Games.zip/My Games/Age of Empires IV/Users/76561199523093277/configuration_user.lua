configuration =  
{
	[1] =  
	{
		setting = "tooltipdelay",
		variantFloat = 0.00000,
	},
	[2] =  
	{
		setting = "texttospeechforchatmessagesxbox",
		variantBool = false,
	},
	[3] =  
	{
		setting = "subtitlebackgroundcolor",
		variantUInt = 0,
	},
	[4] =  
	{
		setting = "buildprogressalwayson",
		variantBool = true,
	},
	[6] =  
	{
		setting = "scrollwheelzoom",
		variantBool = true,
	},
	[7] =  
	{
		setting = "actionlinestoggle",
		variantBool = true,
	},
	[8] =  
	{
		setting = "commandqueuemode",
		variantInt = 0,
	},
	[16] =  
	{
		setting = "pingchatmessages",
		variantBool = true,
	},
	[17] =  
	{
		setting = "eventmajorgamemodeobjectives",
		variantBool = true,
	},
	[18] =  
	{
		setting = "constructionprogressvisibilitymode",
		variantInt = 2,
	},
	[19] =  
	{
		setting = "advancedorders",
		variantBool = false,
	},
	[21] =  
	{
		setting = "autoselectserverregion",
		variantBool = true,
	},
	[23] =  
	{
		setting = "campaigndifficulty",
		variantInt = 1,
	},
	[24] =  
	{
		setting = "playercolour",
		variantBool = true,
	},
	[25] =  
	{
		setting = "minimapresources",
		variantBool = true,
	},
	[26] =  
	{
		setting = "buttonholdtiming",
		variantFloat = 3.00000,
	},
	[27] =  
	{
		setting = "showcontrolgroup",
		variantBool = true,
	},
	[28] =  
	{
		setting = "marqueeholdtime",
		variantFloat = 0.35000,
	},
	[32] =  
	{
		setting = "districttiericonvisibilitymode",
		variantInt = 2,
	},
	[33] =  
	{
		setting = "swapshiftandaltkeys",
		variantBool = false,
	},
	[34] =  
	{
		setting = "uniqueminimapplayericons",
		variantBool = false,
	},
	[35] =  
	{
		setting = "camerarotation",
		variantBool = true,
	},
	[37] =  
	{
		setting = "eventunitcomplete",
		variantBool = true,
	},
	[39] =  
	{
		setting = "eventbuildingcomplete",
		variantBool = true,
	},
	[40] =  
	{
		setting = "marqueeaccelerationisactive",
		variantBool = false,
	},
	[41] =  
	{
		setting = "cyclesubselectionpicktype",
		variantInt = 1,
	},
	[44] =  
	{
		setting = "minimapreticulespeed",
		variantFloat = 15.00000,
	},
	[47] =  
	{
		setting = "rightclickgarrison",
		variantBool = true,
	},
	[48] =  
	{
		setting = "eventageup",
		variantBool = true,
	},
	[49] =  
	{
		setting = "showdamageflashing",
		variantBool = false,
	},
	[50] =  
	{
		setting = "showcanissueresult",
		variantBool = true,
	},
	[51] =  
	{
		setting = "marqueesizemaximum",
		variantInt = 2,
	},
	[53] =  
	{
		setting = "contextualhotkeyicon",
		variantBool = true,
	},
	[54] =  
	{
		setting = "stickyunitsisactive",
		variantBool = true,
	},
	[55] =  
	{
		setting = "showplayerscores",
		variantBool = true,
	},
	[57] =  
	{
		setting = "eventminorcampaignobjectives",
		variantBool = true,
	},
	[58] =  
	{
		setting = "buildinggridoverlay",
		variantInt = 1,
	},
	[59] =  
	{
		setting = "displaynoaudioicon",
		variantBool = false,
	},
	[60] =  
	{
		setting = "cameraresetall",
		variantBool = true,
	},
	[61] =  
	{
		setting = "activescreenedgepanhandler",
		variantString = "screen_edge_pan_default",
	},
	[62] =  
	{
		setting = "showcondensedvictoryobjectives",
		variantBool = true,
	},
	[63] =  
	{
		setting = "loosereticulespeed",
		variantFloat = 50.00000,
	},
	[64] =  
	{
		setting = "camerasnapradius",
		variantFloat = 5.00000,
	},
	[65] =  
	{
		setting = "controllerbuttonminrepeat",
		variantFloat = 0.02000,
	},
	[66] =  
	{
		setting = "minimapzoomlevel",
		variantFloat = 1.00000,
	},
	[67] =  
	{
		setting = "eventupgradecomplete",
		variantBool = true,
	},
	[69] =  
	{
		setting = "custommatchcrossinput",
		variantBool = true,
	},
	[72] =  
	{
		setting = "minimappingnotifications",
		variantBool = true,
	},
	[73] =  
	{
		setting = "edgepanspeedfactor",
		variantFloat = 1.00000,
	},
	[74] =  
	{
		setting = "onlinepresence",
		variantBool = true,
	},
	[75] =  
	{
		setting = "idlevillagerpicktype",
		variantInt = 1,
	},
	[77] =  
	{
		setting = "uielementnarration",
		variantBool = false,
	},
	[78] =  
	{
		setting = "stickyselection",
		variantBool = false,
	},
	[79] =  
	{
		setting = "rumblestrength",
		variantFloat = 1.00000,
	},
	[80] =  
	{
		setting = "allowfriendrequests",
		variantUInt = 0,
	},
	[82] =  
	{
		setting = "contextualcommandtoggle",
		variantBool = true,
	},
	[85] =  
	{
		setting = "analogpanspeed",
		variantFloat = 5.00000,
	},
	[86] =  
	{
		setting = "edgepanacceleration",
		variantFloat = 1.00000,
	},
	[87] =  
	{
		setting = "cycleformationtoggle",
		variantBool = true,
	},
	[89] =  
	{
		setting = "showformationaction",
		variantBool = true,
	},
	[91] =  
	{
		setting = "enabletaunts",
		variantBool = true,
	},
	[92] =  
	{
		setting = "minimapunits",
		variantBool = true,
	},
	[93] =  
	{
		setting = "controllerbuttonmaxrepeat",
		variantFloat = 0.10000,
	},
	[96] =  
	{
		setting = "singleactionwaypointmarkers",
		variantBool = false,
	},
	[97] =  
	{
		setting = "gamewindowactivewhenloaded",
		variantBool = false,
	},
	[98] =  
	{
		setting = "showleadercrown",
		variantBool = true,
	},
	[99] =  
	{
		setting = "loosereticulemode",
		variantUInt = 0,
	},
	[100] =  
	{
		setting = "showgametimer",
		variantBool = false,
	},
	[101] =  
	{
		setting = "lefttriggeristoggle",
		variantBool = true,
	},
	[103] =  
	{
		setting = "mousebuttonpandirection",
		variantString = "reversed",
	},
	[104] =  
	{
		setting = "queuedcommandpriority",
		variantInt = 0,
	},
	[105] =  
	{
		setting = "eventunderattack",
		variantBool = true,
	},
	[106] =  
	{
		setting = "leftthumbstickdeadzone",
		variantFloat = 0.20000,
	},
	[107] =  
	{
		setting = "showidlevillagericons",
		variantBool = true,
	},
	[108] =  
	{
		setting = "reduceflashes",
		variantBool = false,
	},
	[109] =  
	{
		setting = "minimapbuildnotifications",
		variantBool = true,
	},
	[115] =  
	{
		setting = "recentraliseonfullpanisactive",
		variantBool = false,
	},
	[117] =  
	{
		setting = "minimapobjects",
		variantBool = true,
	},
	[121] =  
	{
		setting = "eventunitfound",
		variantBool = true,
	},
	[122] =  
	{
		setting = "showhudcommandwidgets",
		variantBool = true,
	},
	[124] =  
	{
		setting = "rumbletoggle",
		variantBool = true,
	},
	[125] =  
	{
		setting = "reticleactionlinetoggle",
		variantBool = true,
	},
	[126] =  
	{
		setting = "showhudkeybindwidgets",
		variantBool = true,
	},
	[128] =  
	{
		setting = "readincomingtextchat",
		variantBool = false,
	},
	[129] =  
	{
		setting = "recentraliseonrestisactive",
		variantBool = false,
	},
	[130] =  
	{
		setting = "showplayerinfo",
		variantBool = false,
	},
	[132] =  
	{
		setting = "landmarkconstructionprogressvisibilitymode",
		variantBool = true,
	},
	[134] =  
	{
		setting = "slidingnotifications",
		variantBool = true,
	},
	[136] =  
	{
		setting = "controllerbuttonrepeataccelerationlength",
		variantFloat = 4.00000,
	},
	[137] =  
	{
		setting = "eventobjectfound",
		variantBool = true,
	},
	[138] =  
	{
		setting = "usevoicechat",
		variantBool = false,
	},
	[142] =  
	{
		setting = "showhudsubtitles",
		variantBool = true,
	},
	[143] =  
	{
		setting = "classicxpkickers",
		variantBool = true,
	},
	[144] =  
	{
		setting = "customizegamecolors",
		variantUInt = 0,
	},
	[146] =  
	{
		setting = "allowmessages",
		variantUInt = 0,
	},
	[147] =  
	{
		setting = "edgepan",
		variantBool = true,
	},
	[150] =  
	{
		setting = "focusselectedfollow",
		variantInt = 1,
	},
	[151] =  
	{
		setting = "speechtotext",
		variantBool = false,
	},
	[152] =  
	{
		setting = "idlemilitarypicktype",
		variantInt = 1,
	},
	[153] =  
	{
		setting = "rightthumbstickdeadzone",
		variantFloat = 0.20000,
	},
	[154] =  
	{
		setting = "disablebuildingrallypoint",
		variantBool = true,
	},
	[156] =  
	{
		setting = "texttospeechforchatmessagespc",
	},
	[157] =  
	{
		setting = "crossnetwork",
		variantBool = true,
	},
	[160] =  
	{
		setting = "displaykeyboardchaticon",
		variantBool = false,
	},
	[161] =  
	{
		setting = "showunitdescription",
		variantBool = true,
	},
	[163] =  
	{
		setting = "bandboxselect",
		variantKey = "",
	},
	[166] =  
	{
		setting = "eventpopulationcap",
		variantBool = true,
	},
	[168] =  
	{
		setting = "tutorialinterfaceenabled",
		variantBool = true,
	},
	[170] =  
	{
		setting = "showquickfindwidgets",
		variantBool = true,
	},
	[171] =  
	{
		setting = "analogaccelerationspeed",
		variantFloat = 0.00000,
	},
	[172] =  
	{
		setting = "dynamictraining",
		variantBool = true,
	},
	[173] =  
	{
		setting = "voicechatmethod",
		variantUInt = 0,
	},
	[174] =  
	{
		setting = "keyboardpanacceleration",
		variantFloat = 1.00000,
	},
	[177] =  
	{
		setting = "showcustomitems",
		variantBool = true,
	},
	[179] =  
	{
		setting = "controllerbuttonrepeataccelerationstart",
		variantFloat = 1.00000,
	},
	[180] =  
	{
		setting = "findandcyclepicktype",
		variantInt = 1,
	},
	[181] =  
	{
		setting = "campaignautosave",
		variantBool = true,
	},
	[184] =  
	{
		setting = "enablepanaccelerationandsmoothing",
		variantBool = true,
	},
	[186] =  
	{
		setting = "disableunitrallypoint",
		variantBool = false,
	},
	[188] =  
	{
		setting = "mutemicrophone",
		variantBool = true,
	},
	[189] =  
	{
		setting = "layoutcommandcardright",
		variantBool = true,
	},
	[192] =  
	{
		setting = "voicechatvolume",
		variantFloat = 1.00000,
	},
	[194] =  
	{
		setting = "globalbuildqueuevisibility",
		variantInt = 0,
	},
	[197] =  
	{
		setting = "boxselectingdisablesedgepan",
		variantBool = true,
	},
	[199] =  
	{
		setting = "keyboardpanspeedfactor",
		variantFloat = 1.00000,
	},
	[200] =  
	{
		setting = "attackmovebehaviour",
		variantInt = 0,
	},
	[203] =  
	{
		setting = "showpaths",
		variantBool = true,
	},
	[204] =  
	{
		setting = "controlgroupcyclebehaviour",
		variantInt = 1,
	},
	[208] =  
	{
		setting = "snaptoalerttoggle",
		variantBool = true,
	},
	[209] =  
	{
		setting = "analogorbitspeed",
		variantFloat = 50.00000,
	},
	[210] =  
	{
		setting = "healthbarvisibilitymode",
		variantInt = 0,
	},
	[213] =  
	{
		setting = "analogzoomspeed",
		variantFloat = 50.00000,
	},
	[214] =  
	{
		setting = "shownoncriticaleventcues",
		variantBool = true,
	},
	[215] =  
	{
		setting = "campaigndifficultyset",
		variantBool = false,
	},
	[217] =  
	{
		setting = "contextualmilitarycommandtoggle",
		variantBool = true,
	},
	[221] =  
	{
		setting = "camerasnapisactive",
		variantBool = true,
	},
	[226] =  
	{
		setting = "exclusivecontrolgroups",
		variantBool = false,
	},
	[230] =  
	{
		setting = "cameramode",
		variantInt = 0,
	},
	[232] =  
	{
		setting = "showvpswarningmessages",
		variantBool = true,
	},
	[233] =  
	{
		setting = "loosereticuleareawidth",
		variantFloat = 50.00000,
	},
	[234] =  
	{
		setting = "showunitocclusion",
		variantBool = true,
	},
	[235] =  
	{
		setting = "marqueespeed",
		variantFloat = 4.00000,
	},
	[240] =  
	{
		setting = "radialholdtoggle",
		variantUInt = 1,
	},
	[241] =  
	{
		setting = "minimapattacknotifications",
		variantBool = true,
	},
	[243] =  
	{
		setting = "showchattimestamp",
		variantBool = false,
	},
	[244] =  
	{
		setting = "controllerbuttonholdtime",
		variantFloat = 0.29000,
	},
	[245] =  
	{
		setting = "blockugc",
		variantBool = false,
	},
	[247] =  
	{
		setting = "activemousepanhandler",
		variantString = "mouse_pan_default",
	},
	[248] =  
	{
		setting = "minimapbuildings",
		variantBool = true,
	},
	[249] =  
	{
		setting = "activekeyboardpanhandler",
		variantString = "keyboard_pan_default",
	},
	[252] =  
	{
		setting = "eventminorgamemodeobjectives",
		variantBool = true,
	},
}
migrations =  
{
}
version = 3666938

